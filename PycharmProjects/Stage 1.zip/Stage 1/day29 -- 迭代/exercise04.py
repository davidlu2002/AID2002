"""
    exercise04:将迭代器版本的图形管理器改为yield版本的管理器
"""

class Geometry:
    def __init__(self,name):
        self.name = name

class GeometryManager:
    def __init__(self):
        self.__geometry_list = []

    def add_geometry(self,geometry):
        self.__geometry_list.append(geometry)

    def __iter__(self):
        # 执行过程：
        # 1. 调用iter方法不执行（内部创建迭代器对象）
        # 2. 调用next方法才执行
        # 3. 执行完yield语句暂时离开（赋值）
        # 4. 再次调用next方法继续执行
        # 5. 重复第3,4步骤，直至最后
        for item in self.__geometry_list:
            yield item

manager = GeometryManager()
manager.add_geometry(Geometry("正方形"))
manager.add_geometry(Geometry("长方形"))
manager.add_geometry(Geometry("五边形"))

# for item in manager:
#     print(item.name)

iterator = manager.__iter__()
while True:
    try:
        item = iterator.__next__()
        print(item.name)
    except StopIteration:
        break


