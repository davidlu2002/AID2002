"""
    函数式编程 思想
"""
class SkillManager:
    def __init__(self,ID,name,ATK,duration):
        self.ID = ID
        self.name = name
        self.ATK = ATK
        self.duration = duration

    def __str__(self):
        return "{} {}的攻击力是{}，持续时间是{}秒".format(self.ID,self.name,self.ATK,self.duration)


list_skill = [
    SkillManager(101,"乾坤大挪移",100,2),
    SkillManager(102,"降龙十八掌",150,3),
    SkillManager(103,"九阴真经",2000,7)
]

"""
# 需求1 获取ATK大于200的技能数据
def find01():
    for item in list_skill:
        if item.ATK > 200:
            yield item
            
# 需求2 获取持续时间在3-7秒的所有技能数据
def find02():
    for item in list_skill:
        if 3 <= item.duration <= 7:
            yield item
            
# 需求3 获取技能编号是102的技能
def find03():
    for item in list_skill:
        if item.ID == 102:
            return item
        
# 需求4 获取技能名称大于4且持续时间小于6秒的技能数据
def find04():
    for item in list_skill:
        if len(item.name) >= 4 and item.duration < 6:
            yield item
"""


# 封装：分而治之，变则疏之
# 把变化的条件单独定义在函数中
def condition01(item):
    return item.ATK > 200

def condition02(item):
    return 3 <= item.duration <= 7

def condition03(item):
    return item.ID == 102

def condition04(item):
    return len(item.name) >= 4 and item.duration < 6

# 继承：隔离变化
def find(func_condition):
    """
        通用的查找方法
    :param func_condition: 查找条件，函数类型
            函数名(变量) -- > return 布尔类型
    """

    for item in list_skill:
        if func_condition(item):
            yield item

find01 = find(condition01)
for item in find01:
    print(item)

find01 = find(condition02)
for item in find01:
    print(item)





