# exercise_01:请用面向对象的思想描述下列场景：
# 张无忌 教 赵敏 九阳神功
# 赵敏 教 张无忌 化妆
# 张无忌 上班 挣了 10000
# 赵敏 上班 挣了 6000
class Person:
    def __init__(self,name,skill):
        self.name = name
        self.skill = skill

    @property
    def name(self):
        return self.__name
    @name.setter
    def name(self,name):
        self.__name = name

    @property
    def skill(self):
        return self.__skill

    @skill.setter
    def skill(self, skill):
        self.__skill = skill

    def teach(self,person02):
        print("{}教{}{}".format(self.name,person02.name,self.skill))

    def work(self,money):
        print("{}上班挣了{}".format(self.name,money))

person01 = Person("张无忌","九阳神功")
person02 = Person("赵敏","化妆")
teach01 = person01.teach(person02)
teach02 = person02.teach(person01)
work01 = person01.work(10000)
work02 = person02.work(6000)
print("=============================================================")
# exercise_02:请用面向对象的思想描述下列场景：
# 玩家(攻击力)攻击敌人，敌人受伤(血量)，可能死亡(加分)
# 敌人(攻击力)攻击玩家，玩家受伤(血量)，还可能死亡(游戏结束)
class Enemy:
    def __init__(self,name,HP,ATK):
        self.name = name
        self.HP = HP
        self.ATK = ATK

    @property
    def name(self):
        return self.__name
    @name.setter
    def name(self,name):
        self.__name = name

    @property
    def HP(self):
        return self.__HP
    @HP.setter
    def HP(self,HP):
        self.__HP = HP

    @property
    def ATK(self):
        return self.__ATK
    @ATK.setter
    def ATK(self,ATK):
        self.__ATK = ATK

    def is_enemy_dead(self,player):
        if self.HP >= player.ATK:
            return False
        else:
            return True

    def attack(self,player):
        if player.is_player_dead(self):
            print("玩家{}已死亡".format(player.name))
            del player
        else:
            player.HP -= self.ATK



class Player:
    point = 0

    def __init__(self, name, HP, ATK):
        self.name = name
        self.HP = HP
        self.ATK = ATK

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, name):
        self.__name = name

    @property
    def HP(self):
        return self.__HP

    @HP.setter
    def HP(self, HP):
        self.__HP = HP

    @property
    def ATK(self):
        return self.__ATK

    @ATK.setter
    def ATK(self, ATK):
        self.__ATK = ATK

    def is_player_dead(self,enemy):
        if self.HP >= enemy.ATK:
            return False
        else:
            return True

    def attack(self, enemy):
        if enemy.is_enemy_dead(self):
            Player.point += enemy.HP
            print("敌人{}已死亡，加{}分，现在总分为{}".format(enemy.name, enemy.HP, Player.point))

        else:
            enemy.HP -= self.ATK

    @staticmethod
    def pindao(player,enemy,count):
        for i in range(count):
            if enemy.is_enemy_dead(player):
                enemy.HP += i * player.ATK
                Player.point += enemy.HP
                print("拼刀{}次".format(i+1))
                print("敌人{}已死亡，加{}分，现在总分为{}".format(enemy.name, enemy.HP, Player.point))
                break
            if player.is_player_dead(enemy):
                print("玩家{}已死亡".format(player.name))
                del player
            player.attack(enemy)
            enemy.attack(player)
        else:
            print("拼刀{}次，敌人剩余血量{}，玩家剩余血量{}".format(count,enemy.HP,player.HP))


solider = Enemy("士兵",500,50)
heavy_metal = Enemy("重装士兵",2000,150)
player01 = Player("1号",5000,150)
Player.pindao(player01,solider,4)
Player.pindao(player01,heavy_metal,15)

