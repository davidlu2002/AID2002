"""
    类成员(即类变量，存储在类中，被所有对象所共享)
"""
class ICBC:
    """
        工商银行
    """
    # 表示总行的钱
    total_money = 1000000

    @classmethod
    def print_total_money(cls):
        print("总行还剩{}元".format(ICBC.total_money))

    def __init__(self,name,money):
        self.name = name
        self.money = money
        # 表示从总行中扣除支行内的金额
        ICBC.total_money -= money

i01 = ICBC("a支行", 100000)
i02 = ICBC("b支行", 100000)

# 通过类名访问类方法，会将类名传入类方法（将ICBC传给cls）
ICBC.print_total_money()


# exercise_01:创建学生类。
# 1 可以通过类变量记录学生个数
# 2 可以通过类方法打印学生个数
class Student:
    count = 0

    @classmethod
    def print_stu_count(cls):
        print("学生个数为{}".format(Student.count))

    def __init__(self,name,grade):
        self.name = name
        self.grade = grade
        Student.count += 1

stu01 = Student("a",99)
stu02 = Student("b",97)
Student.print_stu_count()
