"""
    内置高阶函数
"""
from common.list_helper import *

class Enemy:
    def __init__(self,name,HP,ATK,defense):
        self.name = name
        self.HP = HP
        self.ATK = ATK
        self.defense = defense

    def __str__(self):
        return "{}的HP是{}，ATK是{}，DEF是{}".format(self.name,self.HP,self.ATK,self.defense)

list_enemy = [
    Enemy("灭霸",10000,500,1000),
    Enemy("奥创",6000,10000,500),
    Enemy("小丑",500,100000,200)
]

"""
# 1. filter:
#   根据条件筛选可迭代对象中的元素(与ListHelper.find_all相同)
# e.g: 获取所有活人
# 方法一：
for item in ListHelper.find_all(list_enemy,lambda item:item.HP>0):
    print(item)
# 方法二：
re = filter(lambda item:item.HP>0,list_enemy)

for item in re:
    print(item)
"""


"""
# 2. map: 与ListHelper.select相同
# e.g: 获取所有敌人的姓名
# 方法一：
for item in ListHelper.select_element(list_enemy,lambda item: item.name):
    print(item)
# 方法二：
re = map(lambda item: item.name,list_enemy)
for item in re:
    print(item)
"""


"""
# 3. max/min: 与ListHelper.get_max/min相同
# 需求：获取血量最大的敌人
print(ListHelper.get_max(list_enemy,lambda item: item.HP))
print(max(list_enemy, key = lambda item: item.HP))
"""


"""
# 4. sorted
#   升序排列
ListHelper.ascending_sort_list(list_enemy, lambda item:item.HP)
for item in list_enemy:
    print(item)

list02 = sorted(list_enemy,key = lambda item:item.ATK)
for item in list02:
    print(item)

#   降序排列
list03 = sorted(list_enemy,key = lambda item:item.ATK,reverse = True)
for item in list03:
    print(item)
"""






