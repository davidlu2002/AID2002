class Skill:
    def __init__(self,name):
        self.name = name

class SKillManager:
    def __init__(self):
        self.__skills = []
        self.__index = 0

    def add_skill(self,skill):
        self.__skills.append(skill)

    def __iter__(self):
        return self

    def __next__(self):
        if self.__index == len(self.__skills):
            raise StopIteration
        self.__index += 1
        return self.__skills[self.__index-1]

manager = SKillManager()
manager.add_skill(Skill("a"))
manager.add_skill(Skill("b"))
manager.add_skill(Skill("c"))

for item in manager:
    print(item.name)

for item in manager:
    print(item.name)