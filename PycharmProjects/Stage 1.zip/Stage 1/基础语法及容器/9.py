# exercise_01:
# list01 = [54,25,12,42,35,17]
# list02 = [i for i in list01 if i > 30]

# # list02 = []
# # for i in list01:
# #     if i > 30:
# #         list02.append(i)

# print(list02)


# exercise_02:
# list01 = []
# times = 0
# max01 = 0
# while times < 5:
#     number = int(input("输入一个数字："))
#     times += 1
#     list01.append(number)
#     if number > max01:
#         max01 = number
# print(list01)
# print(max01)


# exercise_03:
# list01 = [54,25,12,42,35,17]
# max01 = 0
# for number in list01:
#     if number > max01:
#         max01 = number
# print(max01)


# exercise_04:
# list01 = [9,25,12,8]
# for number in range(-len(list01),-1):
#     if list01[number] > 10:
#         list01.remove(list01[number])
# print(list01)


# exercise_05:
# list01 = []
# while True:
#     str_enter = input("输入字符串：")
#     if "" == str_enter:
#         break
#     list01.append(str_enter)
# result = "".join(list01)
# print(result)
# print(list01)


# exercise_06:
# str01 = "How are you"
# list01 = str01.split(" ")
# result = " ".join(list01[::-1])
# print(result)

# import random
# list01 = []
# while len(list01) < 6:
#     red = random.randint(1,33)
#     if red not in list01:
#         list01.append(red)
# blue = random.randint(1,16)
# list01.append(blue)
# print(list01)
#
# list02 = []
# while len(list02) < 6:
#     red = int(input("第{}个红球号码：".format(len(list02)+1)))
#     if red <= 0 or red >=34:
#         print("号码不在范围内，重新输入")
#     elif red in list02:
#         print("号码重复，重新输入")
#     else:
#         list02.append(red)
#
# while len(list02) < 7:
#     blue = int(input("请输入蓝球号码"))
#     if 0 < blue < 17:
#         list02.append(blue)
#     else:
#         print("号码重复，请重新输入")
# print(list02)
#
# times = 0
# for i in range(7):
#     if list01[i] == list02[i]:
#         times += 1
# print(times)

