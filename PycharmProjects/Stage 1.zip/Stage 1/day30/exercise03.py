class SkillManager:
    def __init__(self,ID,name,ATK,duration):
        self.ID = ID
        self.name = name
        self.ATK = ATK
        self.duration = duration

    def __str__(self):
        return "{} {}的攻击力是{}，持续时间是{}秒".format(self.ID,self.name,self.ATK,self.duration)


list_skill = [
    SkillManager(101,"乾坤大挪移",100,2),
    SkillManager(102,"降龙十八掌",150,3),
    SkillManager(103,"九阴真经",2000,7)
]

# 1 获取ATK大于200的技能数据
result01 = (skill for skill in list_skill if skill.ATK >200)
for skill in result01:
    print(skill)
print("====================================")

# 2 获取持续时间在3-7秒的所有技能数据
result02 = [skill for skill in list_skill if 3 <= skill.duration <= 7]
for skill in result02:
    print(skill)
print("====================================")

# 3 获取技能编号是102的技能
result03 = (skill for skill in list_skill if skill.ID == 102)
for skill in result03:
    print(skill)
print("====================================")

# 4 获取技能名称大于4且持续时间小于6秒的技能数据
result04 = (skill for skill in list_skill if len(skill.name) >= 4 and skill.duration < 6)
for skill in result04:
    print(skill)