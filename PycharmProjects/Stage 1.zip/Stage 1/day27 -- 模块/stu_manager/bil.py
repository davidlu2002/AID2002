class StudentManagerController:
    """
        学生管理控制器，负责业务逻辑处理
    """
    def __init__(self):
        self.__stu_list = []

    @property
    def stu_list(self):
        return self.__stu_list

    __initial_ID = 0 # 类变量，初始编号
    def add_student(self,stu_info):
        """
            添加学生
        :param stu_info: 需要添加的学生对象
        """
        StudentManagerController.__initial_ID += 1
        stu_info.ID = StudentManagerController.__initial_ID
        self.stu_list.append(stu_info)

    def delete_student(self,ID):
        """
            根据编号删除学生
        :param ID: 需要删除的学生的编号
        :return: 删除成功/失败
        """
        for student in self.stu_list:
            if student.ID == ID:
                self.stu_list.remove(student)
                return True
        return False

    def update_student(self,stu_upd):
        """
            根据stu_upd.ID修改其他信息
        :param stu_upd: 需要修改的学生信息
        :return: 删除成功/失败
        """
        for student in self.stu_list:
            if student.ID == stu_upd.ID:
                student.name = stu_upd.name
                student.age = stu_upd.age
                student.grade = stu_upd.grade
                return True
        return False

    def ascending_sort_list(self):
        """
            按照成绩升序排列学生
        """
        for k in range(len(self.stu_list) - 1):
            for i in range(k + 1, len(self.stu_list)):
                if self.stu_list[k].grade > self.stu_list[i].grade:
                    self.stu_list[k], self.stu_list[i] = self.stu_list[i],self.stu_list[k]