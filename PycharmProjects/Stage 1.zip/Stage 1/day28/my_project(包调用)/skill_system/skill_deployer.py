def skill_d():
    print("this is skill_deployer")


# 模块导入时，编译器会将被导入的模块内的所有代码执行一遍
# 为了避免测试代码在模块被调用时显示，使用if方法
# __name__: 1 当在本模块中执行时为__main__
#           2 当被别的模块调用时为文件名
if __name__ == "__main__":
    import skill_manager
    skill_manager.skill_m()

    from common.double_list_helper import Double_List
    a = Double_List()
    a.double_list_h()
    a.print_name()

