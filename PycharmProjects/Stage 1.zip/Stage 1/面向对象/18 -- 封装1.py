"""
    封装：即创建一个类
"""
# 1 定义：
#   数据角度讲，将一些基本数据类型复合成一个自定义类型
#   行为角度讲，向类外提供必要的功能，隐藏实现的过程+不必要的功能

# 2 私有成员
# 作用：无需/不想向类外提供的成员
# 做法：命名使用双下弧线__开头

# example:
# class Wife:
#     def __init__(self,name,age,weight):
#         self.name = name
#         # 创建了私有变量
#         # 本质：障眼法（实际将变量名改为：_类名__age/weight）
#         # self.__age = age
#         self.set_age(age)
#         self.__weight = weight
#
#     # 可以用方法操作私有数据
#     def show_age(self):
#         return self.__age
#     def set_age(self,age):
#         if 18 < age < 31:
#             self.__age = age
#         else:
#             raise ValueError("我不要")
#
# w01 = Wife("铁锤公主",19,87)
# # 重新创建了新的实例变量
# # w01.__age = 107
#
# # print(w01.__dict__) # python内置变量，存储着对象的所有的实例变量
#
# w01.set_age(1)
# print(w01.show_age())


# exercise_01:定义敌人类（姓名，攻击力10 -- 50，血量100 -- 200）
#       创建一个敌人对象，可以修改数据
class Enemy:
    def __init__(self,name,attack,HP):
        self.name = name
        self.set_attack(attack)
        self.set_HP(HP)

    def set_attack(self,attack):
        if 10 <= attack <= 50:
            self.__attack = attack
        else:
            raise ValueError("攻击力超出范围")
    def show_attack(self):
        return self.__attack

    def set_HP(self,HP):
        if 100 <= HP <= 200:
            self.__HP = HP
        else:
            raise ValueError("血量超出范围")
    def show_HP(self):
        return self.__HP
soldier = Enemy("士兵",50,100)
print(soldier.show_attack())
print(soldier.show_HP())