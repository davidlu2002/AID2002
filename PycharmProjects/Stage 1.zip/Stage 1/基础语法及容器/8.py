# 1.创建列表
# 空
# list01 = []
# list01 = list()

# e.g:
# list02 = ["悟空", 100, True]
# list02 = list("我叫齐天大圣")


# 2.获取元素：
# 索引
# print(list02[2])
# #切片
# print(list02[-4:])


# 3.添加元素
# append
# list02.append("西游记")

# insert
# list02.insert(2,True)


# 4.删除元素
# 根据元素删除
# list02.remove("我")

# 根据位置删除(反切片)
# del list02[2:7]


# 5.定义元素（可以增删改查）
# 切片
# del list02[1:3] (删除)
# list02[1:3] = ["a","b"] (替换/增删)


# 遍历列表(获取列表中所有元素)
# for i in list02:
#     print(i)


# exercise_01
# list01 = []
# while True:
#     character = input("人物：")
#     if "" == character:
#         break
#     list01.append(character)
# for i in list01:
#     print(i)

# exercise_02:
# grade_list = []
# sum_grade = 0
# while True:
#     str_score = input("成绩：")
#     if "" == str_score:
#         break
#     grade_list.append(int(str_score))
#     sum_grade += int(str_score)
# print("最高分：",max(grade_list))
# print("平均分：",(sum_grade / len(grade_list)))

# exercise_03:
# list01 = []
# while True:
#     name = input("姓名：")
#     if name in list01:
#         print("姓名已经输入")
#     elif "" == name:
#         break
#     else:
#         list01.append(name)
# print(list01[::-1])
list01 = [1,2,3,4]
print(list01[::-1])


