class GoodsModel:
    """
        商品对象
    """
    def __init__(self,ID,name,price):
        self.ID = ID
        self.name = name
        self.price = price

class GoodsController:
    """
        商品控制器，负责业务逻辑处理
    """
    def __init__(self):
        self.dingdan = []

    def add_to_cart(self,goods,count):
        """
            加入购物车
        :param goods: 商品
        :param count: 数量
        """
        self.dingdan.append({goods:count})
    def total_price_cal(self):
        """
            计算订单的总价
        :return: 总价
        """
        zong_jia = 0
        for goods in self.dingdan:
            for goods_info,count in goods.items():
                zong_jia += goods_info.price * count
        return zong_jia

class GoodsView:
    def __init__(self,goods_list):
        self.__controller = GoodsController()
        self.__goods_list = goods_list

    def entry(self):
        """
            显示面板
        :return:
        """
        while True:
            print("1键购买，2键结算，3键退出")
            item = input("请输入：")
            if item == "1":
                self.__display_goods()
                self.__add_to_cart()
            elif item == "2":
                self.__print_dingdan()
                self.__pay()

            elif item == "3":
                break

    def __display_goods(self):
        for goods in self.__goods_list:
            print("编号：%d，名称：%s，单价：%d。" % (goods.ID, goods.name, goods.price))
    def __add_to_cart(self):
        """
            加入购物车
        """
        cid = int(input("请输入商品编号："))
        for goods in self.__goods_list:
            if cid == goods.ID:
                count = int(input("请输入商品数量："))
                self.__controller.add_to_cart(goods,count)
                print("添加到购物车。")
        else:
            print("编号错误，请重新输入。")

    def __print_dingdan(self):
        """
            打印订单
        """
        for goods in self.__controller.dingdan:
            for goods_info, count in goods.items():
                print("商品：{}，单价：{}，数量：{}".format(goods_info.name,goods_info.price,count))
    def __pay(self):
        """
            购买
        """
        total_price = self.__controller.total_price_cal()
        while True:
            qian = float(input("总价%d元，请输入金额：" % total_price))
            if qian >= total_price:
                print("购买成功，找回：%d元。" % (qian - total_price))
                self.__controller.dingdan.clear()
                break
            else:
                print("金额不足。")


shang_pin_info = [
    GoodsModel(101,"屠龙刀",10000),
    GoodsModel(102,"倚天剑",10000),
    GoodsModel(103,"九阴白骨爪",8000),
    GoodsModel(104,"九阳神功",9000),
    GoodsModel(105,"降龙十八掌",8000),
    GoodsModel(106,"乾坤大挪移",10000)
]

view = GoodsView(shang_pin_info)
view.entry()


