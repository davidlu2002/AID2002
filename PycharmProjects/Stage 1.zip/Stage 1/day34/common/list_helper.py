"""
    列表助手模块
"""
class ListHelper:
    """
        列表助手类
    """
    @staticmethod
    def find_all(list_target,func_condition):
        """
            通用的查找某个条件的多个元素的方法
        :param list_target: 需要查找的列表
        :param func_condition: 需要查找的条件
               函数名(参数) -- > bool
        :return: 需要查找的元素,生成器类型
        """
        for item in list_target:
            if func_condition(item):
                yield item

    @staticmethod
    def find_one(list_target,func_condition):
        """
                    通用的查找某个条件的单个元素的方法
                :param list_target: 需要查找的列表
                :param func_condition: 需要查找的条件
                       函数名(参数) -- > bool
                :return: 需要查找的元素
                """
        for item in list_target:
            if func_condition(item):
                return item

    @staticmethod
    def is_exist(list_target,func_condition):
        """
            通用的判断在一个列表中，是否存在至少一个符合条件的元素的方法
        :param list_target: 目标列表
        :param func_condition: 条件
                函数名(参数) -- > bool
        :return: True(存在)/False(不存在)
        """
        for item in list_target:
            if func_condition(item):
                return True
        return False

    @staticmethod
    def sum_element(list_target,func_target_element):
        """
            通用的求和方法
        :param list_target: 目标列表
        :param target_element: 需要求和的元素
                函数名(参数) -- > 数据
        :return: 求和
        """
        sum = 0
        for item in list_target:
            sum += func_target_element(item)
        return sum

    # @staticmethod
    # def select_element(list_target,func_target_element):
    #     """
    #         通用的筛选方法
    #     :param list_target: 目标列表
    #     :param func_target_element: 需要筛选出来的条件
    #             函数名(参数) -- > 具体数据
    #     :return: 包含筛选出的条件的列表
    #     """
    #     list_result = []
    #     for item in list_target:
    #         list_result.append(func_target_element(item))
    #     return list_result

    # 若数据量较大，更倾向于使用生成器模式的方法
    @staticmethod
    def select_element(list_target,func_target_element):
        """
            通用的筛选方法
        :param list_target: 目标列表
        :param func_target_element: 需要筛选出来的条件
                 函数名(参数) -- > 具体数据
        :return: 生成器
        """
        for item in list_target:
            yield func_target_element(item)

    @staticmethod
    def get_max(list_target,func_target_element):
        """
            通用的获取最大元素的方法
        :param list_target: 需要搜索的列表
        :param func_target_element: 需要搜索的逻辑
                函数名(参数) -- > 元素数据(int/float/...)
        :return: 最大元素
        """
        max_item = list_target[0]
        for item in list_target:
            if func_target_element(item) > func_target_element(max_item):
                max_item = item
        return max_item

    @staticmethod
    def get_min(list_target,func_target_element):
        """
            通用的获取最小元素的方法
        :param list_target: 需要搜索的列表
        :param func_target_element: 需要搜索的逻辑
                函数名(参数) -- > 元素数据(int/float/...)
        :return: 最小元素
        """
        min_item = list_target[0]
        for item in list_target:
            if func_target_element(item) < func_target_element(min_item):
                min_item = item
        return min_item

    @staticmethod
    def ascending_sort_list(list_target,func_target_element):
        """
            通用的升序排列方法
        :param list_target: 需要排序的列表
        :param func_target_element: 排序的逻辑
                函数名(参数) -- > 元素数据(int/float/...)
        """
        for k in range(len(list_target) - 1):
            for r in range(k+1,len(list_target)):
                if func_target_element(list_target[k]) > func_target_element(list_target[r]):
                    list_target[k], list_target[r] = list_target[r], list_target[k]

    @staticmethod
    def descending_sort_list(list_target, func_target_element):
        """
            通用的降序排列方法
        :param list_target: 需要排序的列表
        :param func_target_element: 排序的逻辑
                函数名(参数) -- > 元素数据(int/float/...)
        """
        for k in range(len(list_target) - 1):
            for r in range(k + 1, len(list_target)):
                if func_target_element(list_target[k]) < func_target_element(list_target[r]):
                    list_target[k], list_target[r] = list_target[r], list_target[k]

    @staticmethod
    def delete_element(list_target, func_target_element):
        """
            根据指定条件删除元素
        :param list_target: 需要修改的列表
        :param func_target_element: 需要删除的逻辑
                函数名(参数) -- > bool
        """
        for item in range(len(list_target)-1,-1,-1):
            if func_target_element(list_target[item]):
                list_target.remove(list_target[item])

