#a = "A"b = "B"a = bb = "C"print(a)
# print(b)
#注意类型之间的转换

name = input("学生姓名：")
chinese = int(input("语文成绩："))
math = int(input("数学成绩："))
sum = chinese + math
print(name, chinese, math, sum)