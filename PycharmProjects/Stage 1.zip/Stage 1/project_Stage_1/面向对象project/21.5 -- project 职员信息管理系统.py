class Staff:
    def __init__(self,name,basic_salary):
        self.name = name
        self.basic_salary = basic_salary
    def salary_cal(self):
        raise NotImplementedError

class Programmer(Staff):
    def __init__(self,name,basic_salary,fenhong):
        super().__init__(name,basic_salary)
        self.fenhong = fenhong

    def salary_cal(self):
        return self.basic_salary + self.fenhong

class Seller(Staff):
    def __init__(self,name,basic_salary,total_sell):
        super().__init__(name,basic_salary)
        self.total_sell = total_sell

    def salary_cal(self):
        return self.basic_salary + self.total_sell * 0.05


class StaffManagerController:
    def __init__(self):
        self.__staff_list = []
    @property
    def staff_list(self):
        return self.__staff_list

    __initial_ID = 100
    def add_staff(self,staff,ID=0):
        if isinstance(staff,Staff):
            self.__initial_ID += 1
            self.__staff_list.append(staff)
            staff.ID = self.__initial_ID
            print("添加成功")
        else:
            raise ValueError

    def delete_staff(self,ID):
        for staff in self.staff_list:
            if ID == staff.ID:
                self.staff_list.remove(staff)
                return True
        else:
            return False

    def update_staff(self,ID,staff_upd):
        for staff in self.staff_list:
            if ID == staff.ID:
                if isinstance(staff,Programmer):
                    staff.basic_salary = staff_upd.basic_salary
                    staff.fenhong = staff_upd.fenhong
                    return True
                elif isinstance(staff,Seller):
                    staff.basic_salary = staff_upd.basic_salary
                    staff.total_sell = staff_upd.total_sell
                    return True
        else:
            return False


    def get_total_salary(self):
        total_salary = 0
        for staff in self.__staff_list:
            total_salary += staff.salary_cal()
        return total_salary



class StaffView:
    def __init__(self):
        self.__manager = StaffManagerController()

    def __show_menu(self):
        print("1)增加职员")
        print("2)删除职员")
        print("3)更新职员")
        print("4)显示职员")
        print("5)输出总工资")
    def __select_menu(self):
        item = int(input("请输入："))
        if item == 1:
            self.__input_staff()
        elif item == 2:
            self.__del_staff()
        elif item == 3:
            self.__update_staff()
        elif item == 4:
            self.__show_staff()
        elif item == 5:
            self.print_total_salary()
    def entry(self):
        while True:
            self.__show_menu()
            self.__select_menu()

    def __input_staff(self):
        print("职员类型：")
        print("1)程序员")
        print("2)销售员")
        item = int(input("请输入职员类型："))
        if item == 1:
            name = input("请输入职员姓名：")
            basic_salary = int(input("请输入基本工资："))
            fenhong = int(input("请输入分红："))
            programmer = Programmer(name,basic_salary,fenhong)
            self.__manager.add_staff(programmer)
        elif item == 2:
            name = input("请输入职员姓名：")
            basic_salary = int(input("请输入基本工资："))
            total_sell = int(input("请输入销售额："))
            seller = Seller(name,basic_salary,total_sell)
            self.__manager.add_staff(seller)

    def __del_staff(self):
        ID = int(input("请输入所删除职员的ID："))
        if self.__manager.delete_staff(ID):
            print("删除成功。")
        else:
            print("删除失败，未找到该员工。")

    def __update_staff(self):
        ID = int(input("请输入所改动职员的ID："))
        for staff in self.__manager.staff_list:
            if ID == staff.ID:
                if isinstance(staff, Programmer):
                    name = input("请输入改动后的职员姓名：")
                    basic_salary = int(input("请输入改动后的工资："))
                    fenhong = int(input("请输入改动后的分红："))
                    staff.name = name
                    staff.basic_salary = basic_salary
                    staff.fenhong = fenhong
                    print("改动成功")
                elif isinstance(staff, Seller):
                    name = input("请输入改动后的职员姓名：")
                    basic_salary = int(input("请输入改动后的工资："))
                    total_sell = int(input("请输入改动后的销售额："))
                    staff.name = name
                    staff.basic_salary = basic_salary
                    staff.total_sell = total_sell
                    print("改动成功")
        else:
            print("改动失败，未找到该成员。")

    def __show_staff(self):
        for staff in self.__manager.staff_list:
            if isinstance(staff, Programmer):
                print("{}的工资是{}，分红是{}".format(staff.name,staff.basic_salary,staff.fenhong))
            elif isinstance(staff,Seller):
                print("{}的工资是{}，销售额是{}".format(staff.name,staff.basic_salary,staff.total_sell))

    def print_total_salary(self):
        result = self.__manager.get_total_salary()
        print("总工资是%d" % (result))

view = StaffView()
view.entry()



