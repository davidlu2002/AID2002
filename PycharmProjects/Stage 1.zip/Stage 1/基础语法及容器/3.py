#2020.2.27
a = int(input("二次项系数:"))
b = int(input("一次项系数:"))
c = int(input("常数项系数:"))
print("方程为"+str(a)+"X^2+"+str(b)+"X+"+str(c))
delta = b**2 - 4*a*c
if delta < 0:
    print("此方程无解")
elif delta == 0:
    solution = -2 * a / b
    print("X1=X2=",solution)
else:
    print("此方程delta=",delta)
    X1 = int(-b - delta**(1/2))
    X2 = int(-b + delta**(1/2))
    print("此方程两解为"+ "X1=",str(X1),"x2=",str(X2))


