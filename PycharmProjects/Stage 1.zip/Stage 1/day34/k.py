list01 = [1,2,3,4,5]
list02 = list01[1:len(list01)]
print(list02)