"""
    lambda 匿名函数
        语法：lambda 参数列表:函数体
        注意：函数体自带return
"""

from common.list_helper import *
list01 = [3,55,1.6,44,22]

# 1 普通调用方法
"""
def condition01(item):
    return item % 2 == 0

def condition02(item):
    return item > 10

for item in ListHelper.find_all(list01,condition01):
    print(item)
"""

# lambda调用方法
for item in ListHelper.find_all(list01, lambda item: item % 2 == 0 ):
    print(item)

# --------------------------------
# 1 无参数 -- > lambda
def fun01():
    return 100
# 等同于：
a = lambda: 100
# re = a()
# print(re)

# 多参数函数 -- > lambda
def fun02(p1,p2):
    return p1 > p2
# 等同于：
b = lambda p1,p2: p1 > p2
# re = b(1,2)
# print(re)

# 3 无返回值函数 -- > lambda
def fun03(p1):
    print("参数是：",p1)
# 等同于：
c = lambda p1:print("参数是：",p1)
c(100)

# 4 赋值函数 -- > lambda
def fun04(p1):
    p1 = 2
# lambda内方法体只能有一条语句，且不支持赋值语句
# d = lambda p1:p1 = 2