dollar=int(input("美元数量："))
yuan=6.96*dollar
print(dollar,"美元=",yuan,"人民币")