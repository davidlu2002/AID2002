"""
    2048界面
"""

from model import DirectionModel
from controller import GameCoreController

class GameConsoleView:
    def __init__(self):
        self.__controller = GameCoreController()

    def main(self):
        self.__start()
        self.__update()

    def __show_list_2D(self):
        for line in self.__controller.list_2D:
            print(line)

    def __start(self):
        self.__controller.generate_random_number()
        self.__controller.generate_random_number()
        self.__show_list_2D()

    def __update(self):
        while True:
            if self.__controller.if_game_over():
                print("游戏结束")
                break
            else:
                order = input("请输入命令：")
                if order == "左":
                    self.__controller.move(DirectionModel.LEFT)
                    self.__show_list_2D()
                elif order == "右":
                    self.__controller.move(DirectionModel.RIGHT)
                    self.__show_list_2D()
                elif order == "上":
                    self.__controller.move(DirectionModel.UP)
                    self.__show_list_2D()
                elif order == "下":
                    self.__controller.move(DirectionModel.DOWN)
                    self.__show_list_2D()
                else:
                    print("输入错误，请重新输入")

entry = GameConsoleView()
entry.main()
