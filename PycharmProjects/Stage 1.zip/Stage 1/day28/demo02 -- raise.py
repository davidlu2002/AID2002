"""
    raise:抛出异常

自定义异常：
    好处： 1 可以DIY，将我们想给出的信息填入
          2 可以见名知意
"""

class AgeError(Exception):
    def __init__(self,a,b,c,d):
        self.a = a
        self.b = b
        self.c = c
        self.d = d



class Wife:
    def __init__(self,age):
        self.age = age

    @property
    def age(self):
        return self.__age
    @age.setter
    def age(self,value):
        if 21 <= value <= 31:
            self.__age  = value
        else:
            raise AgeError("超过年龄范围",value,26,101)
try:
    w01 = Wife(88)
except AgeError as e:
    print("值异常，请重新输入")
    print("{}{}".format(e.b,e.a))

