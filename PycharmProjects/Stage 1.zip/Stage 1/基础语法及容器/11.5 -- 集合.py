# exercise_01
# list_year = [year for year in range(1970,2051) if year % 4 == 0 and year % 100 != 0 or year % 400 == 0]
# # for year in range(1970,2051):
# #     if year % 4 == 0 and year % 100 != 0 or year % 400 == 0:
# #         list_year.append(year)
# print(list_year)


# exercise_02:
# dict_result = {}
# str_target = input("输入一个字符串：")
# for item in str_target:
#     if item not in dict_result:
#         dict_result[item] = 1
#     else:
#         dict_result[item] += 1
# print(dict_result)

"""
    字典推导式
"""

# 语法一：
# dict_result = {}
# for i in range(1,11):
#     if i > 5:
#         dict_result[i] = i ** 2
# print(dict_result)
#
# dict02 ={i : i ** 2 for i in range(1,11) if i > 5}
# print(dict02)

# 语法二：
# dict01 = {}
# for i in range(1,11):
#     if i % 2 == 0:
#         dict01[i] = "haha"
#     else:
#         dict01[i] == "heihei"
# dict01 = {i : "haha" if i % 2 == 0 else "heihei" for i in range(1,11)}


# exercise_01:
# list01 = ["wj", "zm", "zjr"]
# dict01 = {item : len(item) for item in list01}
# print(dict01)

# list02 = [101,102,103]
# dict02 = {list01[i] : list02[i] for i in range(0,3)}
# print(dict02)

"""
    集合(相当于只有键没有值的字典)
"""

# 1 创建集合
# set01 = set("abcabc")
# # set02 = set([1,2,3])
# # set03 = set((1,2,3))
# # set04 = set({"a":1, "b":2})


# # 2 添加元素
# set01.add(1)
# print(set01)

# 3 删除元素
# set01.remove(1)

# 4 数学运算
# 交集(返回两个集合中相同的元素)
# set01 = {1,2,3}
# set02 = {2,3,4}
# set03 = set01 & set02

# 并集(返回两个集合内不重复的所有元素)
# set04 = set01 | set02

# 补集(返回两个集合中不同的元素)
# set05 = print(set01 ^ set02)
# set05 = print(set01 - set02)

# 子集
# set06 = {1,2}
# print(set06 < set01)

# 超集
# set07 = {1,2,3,4}
# print(set07 > set01)


# exercise_01
set_str = set()
while True:
    str_input = input("输入字符串：")
    if "" == str_input:
        break
    set_str.add(str_input)
print(set_str)

# exercise_02:
set_manager = {"曹操","刘备","孙权"}
set_tech = {"曹操","刘备","关羽","张飞"}
print("都是的有"+str(set_manager & set_tech))
print("是经理，不是技术的有"+str(set_manager -set_tech))
print("是技术，不是经理的有"+str(set_tech - set_manager))
print("张飞是经理吗？","张飞" in set_manager)
print("身兼一职的有"+str(set_manager ^ set_tech))
print("经理和技术总共有{}人".format(len(set_tech | set_manager)))

"""
    固定集合：不能变的集合(只能创建)
"""
set01 = frozenset()


