class SkillEffect:
    def effect(self):
        pass

class DamageEffect(SkillEffect):
    def __init__(self,value):
        self.ATK = value

    def effect(self):
        print("造成{}点伤害".format(self.ATK))

class DefendEffect(SkillEffect):
    def __init__(self,value):
        self.defense = value

    def effect(self):
        print("防御增加{}点".format(self.defense))

class StunEffect(SkillEffect):
    def __init__(self,value):
        self.time = value

    def effect(self):
        print("眩晕{}秒".format(self.time))

class SilenceEffect(SkillEffect):
    def __init__(self,value):
        self.time = value

    def effect(self):
        print("沉默{}秒".format(self.time))



class SkillController:
    def __load_skill_config(self):
        return {
            "北冥神功": ["DamageEffect(50)","SilenceEffect(2)"],
            "降龙十八掌": ["DamageEffect(80)","DefendEffect(100)","StunEffect(0.5)"]
        }

    def create_skill(self,name):
        skill_dict = self.__load_skill_config()
        for key, skill_effect_list in skill_dict.items():
            if key == name:
                list_effect = []
                for str_skill_effect in skill_effect_list:
                    skill_effect = eval(str_skill_effect)
                    list_effect.append(skill_effect)
                return {name:list_effect}
        raise ValueError("未找到该技能")

    def release_skill(self,skill_name):
        skill_dict = self.create_skill(skill_name)
        for skill,skill_effect_list in skill_dict.items():
            if skill_name == skill:
                print("释放{}".format(skill))
                for skill_effect in skill_effect_list:
                    skill_effect.effect()

entry = SkillController()
entry.release_skill("降龙十八掌")
entry.release_skill("北冥神功")






