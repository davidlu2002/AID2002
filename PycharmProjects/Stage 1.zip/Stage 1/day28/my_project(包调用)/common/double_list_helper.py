class Double_List:
    def double_list_h(self):
        print("this is double_list_helper")
    @staticmethod
    def print_name():
        print("the name is Double_List")