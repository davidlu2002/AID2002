"""
    生成器表达式
"""

list01 = [3,"32523",55,"asdf",True,1.6,"Fas"]

# 1 生成器函数
def get_int(list_target):
    for item in list_target:
        if isinstance(item, int):
            yield item

get01 = get_int(list01)
for item in get01:
    print(item)


# 2 生成器表达式
result = (item + 1 for item in list01 if isinstance(item, int))
for item in result:
    print(item)


# 3 列表推导式(小括号换中括号)
result = [item for item in list01 if isinstance(item,int)]
print(result)



"""
    总结：
1.列表推导式
变量 = [item for item in 可迭代对象 if 条件]

2.字典推导式
变量 = {k,v for k,v in 可迭代对象 if 条件}

3.集合推导式
变量 = {item for item in 可迭代对象 if 条件}

4.生成器表达式
变量 = (item for item in 可迭代对象 if 条件)
"""
