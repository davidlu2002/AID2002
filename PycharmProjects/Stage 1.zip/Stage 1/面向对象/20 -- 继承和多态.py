"""
    继承 -- 方法
"""
class Person:
    def say(self):
        print("say")

class Student(Person):
    def study(self):
        print("study")

class Teacher(Person):
    def teach(self):
        print("teach")

p01 = Person()
s01 = Student()
t01 = Teacher()



# python内置函数
# 1 判断对象是否属于一个类型
# print(isinstance(t01,Teacher))
# print(isinstance(t01,Person))
# print(isinstance(t01,Student))

# 2 判断一个类型是否属于一个类型
# print(issubclass(Teacher,Student))
# print(issubclass(Teacher,Person))


# exercise_01:
# class Animal:
#     def move(self):
#         print("move")
# class Dog(Animal):
#     def bite(self):
#         print("bite")
#     def run(self):
#         print("run")
#
# class Bird:
#     def fly(self):
#         print("fly")
#
# dog01 = Dog()
# bird01 = Bird()
# animal01 = Animal()
#
# print(isinstance(dog01,Animal))
# print(isinstance(bird01,Dog))
# print(issubclass(Dog,Animal))
# print(issubclass(Animal,Dog))


"""
    继承 -- 变量
"""
# class Person:
#     def __init__(self,name):
#         self.name = name
#
# class Student(Person):
#     # 子类若没有构造函数，使用父类的
#     pass
# s01 = Student("zs")
# print(s01.name)

# class Person:
#     def __init__(self,name):
#         self.name = name
#
# class Student(Person):
#     #子类若具有构造函数，则必须先调用父类构造函数
#     def __init__(self,name,score):
#         super().__init__(name)
#         self.score = score
# s01 = Student("zs",100)
# print(s01.name)
# print(s01.score)


# exercise_02:
# 定义父类（车）
# 定义子类（电动车）

# class Car:
#     def __init__(self,speed,price):
#         self.speed = speed
#         self.price = price
#
# class Elec_Car(Car):
#     def __init__(self,speed,price,power):
#         super().__init__(speed,price)
#         self.total_power = power
#
# car01 = Car(80,10000)
# car02 = Elec_Car(40,2000,1500)


