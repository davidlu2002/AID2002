"""
    exercise_03:定义MyRange类，实现下列功能
    for item in MyRange(10):
        print(item)
"""
class MyRange:
    def __init__(self,value):
        self.value = value

    def __iter__(self):
        return MyRangeIterator(self.value)

class MyRangeIterator:
    def __init__(self,value):
        self.value = value
        self.index = 0

    def __next__(self):
        if self.index == self.value:
            raise StopIteration
        temp = self.index
        self.index += 1
        return temp
# 方法一：
# for item in MyRange(15):
#     print(item)

# 方法二：
# a = MyRange(15)
# iterator = a.__iter__()
# while True:
#     try:
#         item = iterator.__next__()
#         print(item)
#     except StopIteration:
#         break

