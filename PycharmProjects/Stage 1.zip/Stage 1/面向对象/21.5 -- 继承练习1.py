"""
    定义图形管理器类
        1.管理所有图形
        2.提供计算所有图形总面积的方法

    具体图形：
        circle,rectangle,...

    要求：增加新图形，图形管理器不受影响
"""
# class FigureManager:
#     def __init__(self):
#         self.__figure_list = []
#
#     def add_figure(self,figure):
#         if isinstance(figure,Figure):
#             self.__figure_list.append(figure)
#             print("添加成功")
#         else:
#             raise ValueError
#
#     def get_total_area(self):
#         total_area = 0
#         for figure in self.__figure_list:
#             total_area += figure.area_cal()
#         return total_area
#
#
#
# class Figure:
#     def area_cal(self):
#         raise NotImplementedError
#
# class Circle(Figure):
#     def __init__(self,radius):
#         self.radius = radius
#
#     def area_cal(self):
#         return 3.14 * self.radius ** 2
#
# class Rectangle(Figure):
#     def __init__(self,length,width):
#         self.length = length
#         self.width = width
#
#     def area_cal(self):
#         return self.length * self.width
#
# manager = FigureManager()
# circle01 = Circle(10)
# rec01 = Rectangle(5,5)
#
# manager.add_figure(circle01)
# manager.add_figure(rec01)
#
# print(manager.get_total_area())


"""
    定义员工管理器
        1.管理所有员工
        2.计算所有员工工资
    
    员工：
        程序员：底薪 + 项目分红
        销售：底薪 + 销售额 * 0.05
        ...
    要求：增加新岗位，员工管理器不受影响
"""
class StaffManager:
    def __init__(self):
        self.__staff_list = []

    def add_staff(self,staff):
        if isinstance(staff,Staff):
            self.__staff_list.append(staff)
            print("添加成功")
        else:
            raise ValueError

    def get_total_salary(self):
        total_salary = 0
        for staff in self.__staff_list:
            total_salary += staff.salary_cal()
        return total_salary

class Staff:
    def __init__(self,basic_salary):
        self.basic_salary = basic_salary

    def salary_cal(self):
        raise NotImplementedError

class Programmer(Staff):
    def __init__(self,basic_salary,fenhong):
        super().__init__(basic_salary)
        self.fenhong = fenhong

    def salary_cal(self):
        return self.basic_salary + self.fenhong

class Seller(Staff):
    def __init__(self,basic_salary,total_sell):
        super().__init__(basic_salary)
        self.total_sell = total_sell

    def salary_cal(self):
        return self.basic_salary + self.total_sell * 0.05

class Tester(Staff):
    def __init__(self,basic_salary,bug):
        super().__init__(basic_salary)
        self.bug = bug

    def salary_cal(self):
        return self.basic_salary + self.bug * 5


manager = StaffManager()
p01 = Programmer(8000,15000)
s01 = Seller(4000,300000)
t01 = Tester(12000,500)
manager.add_staff(p01)
manager.add_staff(s01)
manager.add_staff(t01)
print(manager.get_total_salary())
