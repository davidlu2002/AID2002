#在控制台获取一个字符串

# str01 = "我叫齐天大圣"
# exercise_01: 打印第一个字符
# print(str01[0])

# exercise_02: 打印最后一个字符
# print(str01[-1])

# exercise_03: 打印倒数第三个字符
# print(str01[-3])

# exercise_04: 打印前两个字符
# print(str01[0:2])

# exercise_05: 倒序打印字符
# print(str01[-1:-7:-1]) OR
# print(str01[::-1])

# exercise_06: 如果字符串长度是奇数，打印中间的字符
# if len(str01) % 2 == 1:
#     print(str01[len(str01) // 2])

# exercise_07：
# name = "悟空"
# age = 800
# score = 99.5
# print("我叫{},年龄是{},成绩是{}". format(name, age, score))

# exercise_08: 在控制台获取一个整数作为边长并打印一个正方形
# while True:
#     length = int(input("正方形边长为(退出输入0)："))
#     if length < 2:
#         print("边长至少为2，请重新输入。")
#     elif length == "0":
#         break
#     for i in range(1,length+1):
#         if i == 1 or i == length:
#             print("*" * length )
#         else:
#             print("*" + " " * (length - 2) + "*")

# exercise_09:
# str01 = input("输入一个字符串：")
# if str01 == str01[::-1]:
#     print("是回文")
# else:
#     print("不是回文")

#exercise_10:
# initial_height = 100
# sum_height = 100
# count = 0
# while initial_height > 0.01:
#     initial_height *= 1/2
#     count += 1
#     sum_height += initial_height * 2
# print("弹起次数为"+str(count)+"次")
# print("总弹起高度为"+str(sum_height)+"m")




