"""
    双重for循环
"""
# exercise_01: 升序排列list01
# list01 = [3,80,45,5,7,1,80]
# for k in range(len(list01)-1):
#     for i in range(k+1,len(list01)):
#         if list01[k] > list01[i]:
#             list01[k],list01[i] = list01[i],list01[k]
# print(list01)

# exercise_02:冒泡排序（降序）（相邻元素比较大小.每次都会把最大/最小的数放到最后）
# list02 = [1, 3, 5, 7, 45, 80]
# for r in range(len(list01)-1):
#     for k in range(len(list01)-r-1):
#         if list01[k] < list01[k+1]:
#             list01[k],list01[k+1] = list01[k+1],list01[k]
# print(list02)

# exercise_03:
# list03 = [3,80,45,5,7,1,80]
# list04 = []
# for k in range(0,len(list03)-1):
#     for i in range(k+1,len(list03)):
#         if list03[k] == list03[i]:
#             list04.append(list01[k])
#             print("相同的是", list03[k])
# if len(list04) == 0:
#     print("没有相同项")

# exercise_04: 列换行
# list05 = [
#     [1,2,3,4],
#     [5,6,7,8],
#     [9,10,11,12],
#     [13,14,15,16]
# ]
# list06 = []
# for r in range(4):
#     list07 = []
#     for k in range(4):
#         list07.append(list05[k][r])
#     list06.append(list07)
# for item in list06:
#     print(item)

# exercise_05:方阵转置
# list03 = [
#     [1,2,3,4],
#     [5,6,7,8],
#     [9,10,11,12],
#     [13,14,15,16]
# ]

# 方法一
# for r in range(4):
#     for k in range(4):
#         if r > k:
#             list03[k][r],list03[r][k] = list03[r][k],list03[k][r]
# print(list03)

# 方法二
# for k in range(3):
#     for r in range(k+1,4):
#         list03[r][k],list03[k][r] = list03[k][r],list03[r][k]
# print(list03)


"""
    列表推导式嵌套
"""
# list01 = ["a", "b", "c"]
# list02 = ["A", "B", "C"]
# list03 = [r + k for r in list01 for k in list02]
# # for r in list01:
# #     for k in list02:
# #         list03.append(r + k)
# print(list03)

# execise_01: 列表的全排列
# fruit = ["香蕉","苹果", "哈密瓜"]
# drink = ["可乐", "牛奶"]
# all_combination = [f + d for f in fruit for d in drink]
# print(all_combination)


