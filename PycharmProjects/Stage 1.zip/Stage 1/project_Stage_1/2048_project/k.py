"""
list01 = [
    [1,2,3,4],
    [5,6,7,8],
    [9,10,11,12],
    [13,14,15,16]
]

for line in list01:
    line_intermediate = line[::-1]
    line_intermediate[0] = 10
    # line[::-1] = line_intermediate
    line = line_intermediate[::-1]
"""

"""
import copy
a = [1, [2, 3]]
b = copy.deepcopy(a)


print(id(a),id(a[0]),id(a[1]))
print(id(b),id(b[0]),id(b[1]))
print("==============================")
"""

"""
def fun01(**kwargs):
    print(kwargs)

fun01(a=1, b=2)
"""





import time
def get_action_time(list_target, func):
    start_time = time.time()
    func(list_target)
    end_time = time.time()
    print(end_time - start_time)

list01 = []
for item in range(10000):
    list01.append(item)

# start_time01 = time.time()
# list01.append(100)
# end_time01 = time.time()
# print(end_time01 - start_time01)

# start_time02 = time.time()
# list01.insert(2,100)
# end_time02 = time.time()
# print(end_time02 - start_time02)

get_action_time(list01, lambda item: item.insert(112,100))
get_action_time(list01, lambda item: item.append(100))

