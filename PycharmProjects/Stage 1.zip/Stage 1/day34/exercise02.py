# 根据指定条件，删除敌人列表中的元素
# 1 删除所有死人
# 2 删除所有攻击力小于5000的敌人
# 3 删除所有防御力大于300的敌人

class Enemy:
    def __init__(self,name,HP,ATK,defense):
        self.name = name
        self.HP = HP
        self.ATK = ATK
        self.defense = defense

    def __str__(self):
        return "{}的HP是{}，ATK是{}，DEF是{}".format(self.name,self.HP,self.ATK,self.defense)

list_enemy = [
    Enemy("灭霸",10000,500,1000),
    Enemy("奥创",6000,10000,500),
    Enemy("小丑",500,100000,200),
    Enemy("钢铁侠",0,8000,500)
]

from common.list_helper import *
# ListHelper.delete_element(list_enemy, lambda item: item.HP == 0)

# ListHelper.delete_element(list_enemy, lambda item: item.ATK < 5000)
# for item in list_eneListHelper.delete_element(list_enemymy:
#     print(item)

ListHelper.delete_element(list_enemy, lambda item: item.defense > 300)
for item in list_enemy:
    print(item)