"""
    exercise01:定义生成器函数my_enumerate,实现下列现象
        将元素和索引合成一个元组
"""

"""
list01 = [3,4,55,6,7]
for item in enumerate(list01):
    # (索引,元素)
    print(item)

for index, element in enumerate(list01):
    print(index,element)


def my_enumerate(list_target):
    for index in range(len(list_target)):
        yield (index,list_target[index])

my01 = my_enumerate(list01)
for item in my01:
    print(item)
"""

# exercise02: 定义生成器函数my_zip,实现下列现象
# 将多个列表的每个元素合成一个元组
list02 = ["孙悟空","猪八戒","唐僧","沙僧"]
list03 = [101,102,103,104,105]

# for item in zip(list03,list02):
#     print(item)

def get_min_index(target):
    """
        找到最小的索引值
    :param target: 目标容器
    :return: 容器内最小的索引值
    """
    min_index = len(target[0])
    for item in target:
        if len(item) < min_index:
            min_index = len(item)
    return min_index


def my_zip(*args):
    """
        将几个容器内的元素组合成元组
    :param args: 需要合成的容器
    """
    # min_index = get_min_index(args)
    # 或者使用：
    min_index = len(min(args, key = lambda item: len(item)))
    for index in range(min_index):
        list_result = []
        for item in args:
            list_result.append(item[index])

        yield tuple(list_result)

my02 = my_zip(list03,list02)
for item in my02:
    print(item)