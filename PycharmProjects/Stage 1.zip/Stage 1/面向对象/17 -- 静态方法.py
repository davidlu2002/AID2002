"""
    静态方法

    总结：
        实例方法：操作对象的变量
        类方法：操作类的变量
        静态方法：既不需要操作实例变量也不需要操作类变量
"""
list01 = [
    ["00","01","02","03"],
    ["10","11","12","13"],
    ["20","21","22","23"],
]

class Vector2:
    """
        二维向量类(可以表示位置+方向)
    """
    def __init__(self,x,y):
        self.x = x
        self.y = y

    # 静态方法：表示左边方向
    @ staticmethod
    def left():
        return Vector2(0,-1)
    # 静态方法：表示右边方向
    @staticmethod
    def right():
        return Vector2(0,1)

    @staticmethod
    def up():
        return Vector2(-1, 0)

    @staticmethod
    def down():
        return Vector2(1, 0)

# 作用：位置 + 方向
pos01 = Vector2(1,2)
l01 = Vector2.left()
pos01.x += l01.x
pos01.y += l01.y
print(pos01.x,pos01.y)


# exercise_01: 在二维列表中获取指定位置，方向，和数量的元素
# 例如：list01 "10" 右边 3 --> "11", "12", "13"
class Double_ListHelper:
    @staticmethod
    def get_elements(list_target,vect_pos,vect_dir,count):
        """
            在二维列表中获取指定位置，方向，和数量的元素
        :param list_target: 二维列表
        :param vect_pos: 指定位置
        :param vect_dir: 指定方向
        :param count: 指定数量
        :return: 结果
        """
        list_result = []
        for i in range(count):
            vect_pos.x += vect_dir.x
            vect_pos.y += vect_dir.y
            element = list_target[vect_pos.x][vect_pos.y]
            list_result.append(element)
        return list_result

result = Double_ListHelper.get_elements(list01,Vector2(1,0),Vector2.right(),3)
print(result)

# exercise_02:
# 1 获取13位置，向左，3个元素
result = Double_ListHelper.get_elements(list01,Vector2(1,3),Vector2.left(),3)
print(result)
# 2 获取22位置，向上，2个元素
result = Double_ListHelper.get_elements(list01,Vector2(2,2),Vector2.up(),2)
print(result)
# 3 获取03位置，向下，2个元素
result = Double_ListHelper.get_elements(list01,Vector2(0,3),Vector2.down(),2)
print(result)
print("======================================")

# exercise_03: 定义敌人类
#   -- 数据：姓名，血量，基础攻击力，防御力
#   -- 行为：打印个人信息
# 创建敌人列表
class Enemy:
    def __init__(self,name,blood,attack,defense):
        self.name = name
        self.blood = blood
        self.attack = attack
        self.defense = defense

    def print_enemy_info(self):
        print("{}的血量是{}，攻击力是{}，防御力是{}".format(self.name,self.blood,self.attack,self.defense))

normal_soldier = Enemy("士兵",1000,200,100)
heavy_metal = Enemy("重装士兵",5000,300,600)
great_heavy_metal = Enemy("高级重装士兵",8000,400,800)
butcher = Enemy("屠夫",10000,500,200)
list_enemy = [normal_soldier,heavy_metal,great_heavy_metal,butcher]
# 查找姓名是"重装士兵"的敌人对象
for enemy in list_enemy:
    if enemy.name == "重装士兵":
        enemy.print_enemy_info()

# 计算所有敌人的平均攻击力
total_attack = 0
for enemy in list_enemy:
    total_attack += enemy.attack
print("平均攻击力是{}".format(total_attack / len(list_enemy)))

# 删除防御力小于500的敌人
def delete_defense_500():
    for i in range(len(list_enemy)-1,-1,-1):
        if list_enemy[i].defense < 500:
            print("删除%s角色" % (list_enemy[i].name))
            list_enemy.pop(i)
delete_defense_500()

# 将所有敌人攻击力提高50
for enemy in list_enemy:
    enemy.attack += 50
    enemy.print_enemy_info()