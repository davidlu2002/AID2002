list_student_hobby = []
while True:
    name = input("姓名：")
    if "" == name:
        break
    times = 1
    list_hobby = []
    while True:
        hobby = input("第{}个喜好：".format(times))
        if "" == hobby:
            break
        times += 1
        list_hobby.append(hobby)
    dict_name_hobby = {name:list_hobby}
    list_student_hobby.append(dict_name_hobby)
for dict_name_hobby in list_student_hobby:
    for name in dict_name_hobby:
        print("{}有{}个喜好".format(name, len(list_hobby)))
        for hobby_number in range(0,len(list_hobby)):
            print("第{}个喜好是{}".format(hobby_number+1, list_hobby[hobby_number]))