from common.list_helper import *

class SkillManager:
    def __init__(self,ID,name,ATK,duration):
        self.ID = ID
        self.name = name
        self.ATK = ATK
        self.duration = duration

    def __str__(self):
        return "{} {}的攻击力是{}，持续时间是{}秒".format(self.ID,self.name,self.ATK,self.duration)

list_skill = [
    SkillManager(101,"乾坤大挪移",100,2),
    SkillManager(102,"降龙十八掌",150,3),
    SkillManager(103,"九阴真经",2000,7)
]

# 需求：使用lambda
# 练习1 名称大于4的技能
find01 = ListHelper.find_all(list_skill, lambda skill: len(skill.name) > 4)
for skill in find01:
    print(skill)
print("========================================")

# 练习2 持续时间小于等于5的技能数量
find02 = ListHelper.find_all(list_skill, lambda skill: skill.duration <= 5)
for skill in find02:
    print(skill)





