"""
    时间模块,time
"""
import time
# 1 获取当前的时间戳
#   时间戳：从1970.1.1到现在所经过的秒数
print(time.time())
print("=========================")

# 2 时间元组：返回1970.1.1+输入秒数的具体时间
print(time.localtime(1585662179))
print(time.localtime())
print("========================")

# 2.1 mktime: 将时间元组转变为时间戳
tuple_tm = time.localtime()
print(time.mktime(tuple_tm))
print("==========================")

# 2.2 时间元组转变为字符串
str_time = time.strftime("%Y/%m/%d %H:%M:%S",tuple_tm)
print(str_time)
print("==============================")

# 2.3 字符串转变为时间元组    parse:解析
result = time.strptime("2020/03/31 21:59:33", "%Y/%m/%d %H:%M:%S")
print(result)

