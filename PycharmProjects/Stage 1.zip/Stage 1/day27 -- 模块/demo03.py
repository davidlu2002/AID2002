"""
    根据生日，计算总共活了多少天
"""
import time
def get_alive_day(year,month,day):
    time_tuple = time.strptime("{}/{}/{}".format(year, month, day), "%Y/%m/%d")
    total_second = time.time()
    second = time.mktime(time_tuple)
    alive_second = total_second - second
    alive_day = alive_second / (3600 * 24)
    alive_year = alive_day / 365
    return alive_day,alive_year

print(get_alive_day(2020,3,11))
print(85 / 100 * 90)