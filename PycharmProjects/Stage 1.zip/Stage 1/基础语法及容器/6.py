#exercise_01
# height = float(input("身高（米）："))
# weight = float(input("体重（kg）："))
# BMI = weight / height ** 2
# print(BMI)
# if BMI < 18.5:
#     print("体重过低")
# elif 18.5 <= BMI < 24:
#     print("正常")
# elif 24 <= BMI:
#     print("肥胖")

#exercise_02
# begin = int(input("开始值："))
# end = int(input("结束值："))
# if begin < end:
#     while begin < end - 1:
#         begin += 1
#         print(begin)
# else:
#     print("开始值必须小于结束值")

#exercise_03
# initial_thickness = float(0.01)
# number = 0
# while initial_thickness < 8844.43 * 1000:
#     initial_thickness *= 2
#     number += 1
# print(number)

#exercise_04
# import random
# real_number = random.randint(1,100)
# times = 0
# while True:
#     guess = int(input("输入一个数："))
#     times += 1
#     if guess == real_number:
#         print("猜对了,总共猜了"+str(times)+"次")
#         break
#     elif guess < real_number:
#         print("小了")
#     else:
#         print("大了")

#exercise_05
# times = 0
# while True:
#     grade = float(input("输入成绩："))
#     if 80 < grade <= 100:
#         print("优秀")
#     elif 60 < grade <= 80:
#         print("良好")
#     elif grade == 60:
#         print("及格")
#     elif 0 <= grade < 60:
#         print("不及格")
#     else:
#         print("输入有误，重新输入")
#         times += 1
#     if times == 3:
#         print("输入错误次数过多")
#         break
#     if "" == input("退出请按回车："):
#         break

# for: 适合执行预定次数
#   规定了程序执行的次数
# while: 适合根据条件循环执行（未知次数）
#    要注意找到程序break的点

# exercise_01
# sum = 0
# for number in range(10,36):
#     sum += number
# print(sum)

number = int(input("输入一个整数："))
for i in range(2,number):
    if number % i == 0:
        print("不是素数")
        break
else:
    print("是素数")