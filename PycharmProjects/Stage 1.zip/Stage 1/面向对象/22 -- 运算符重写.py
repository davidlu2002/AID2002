"""
    运算符重写
"""
# python中，以双下划线开头和结尾的方法是系统内置方法（如__init__）
# class StudentModel:
#     def __init__(self, name="", age=0, score=0, ID=0):
#         self.name = name
#         self.age = age
#         self.score = score
#         self.ID = ID
#
#     def __str__(self):
#         return "{}的年龄是{}，成绩是{}，编号是{}".format(self.name, self.age, self.score, self.ID)
#
#     def __repr__(self):
#         return "StudentModel('{}',{},{},{})".format(self.name, self.age, self.score, self.ID)
#
# s01 = StudentModel("a",17,88,1)
# str01 = str(s01)
# print(str01)
#
# print("=======================")
#
# # repr返回python格式的字符串
# s02 = repr(s01)
# print(s02,type(s02))
#
# print("=====================")
#
# # eval根据字符串执行代码
# s03 = eval(s02)
# print(s03,type(s03))
# # repr和eval合用，克隆了一个新的对象


# exercise_01:
# 1 创建Enemy类对象，将对象打印在控制台上
# 2 克隆Enemy类对象，体会克隆对象的改变不影响原对象
class Enemy:
    def __init__(self,name,ATK,HP):
        self.name = name
        self.ATK =ATK
        self.HP = HP

    def __str__(self):
        return "{}的攻击力是{}，血量是{}".format(self.name,self.ATK,self.HP)

    def __repr__(self):
        return "Enemy('{}',{},{})".format(self.name,self.ATK,self.HP)

e01 = Enemy("a", 50, 100)
print(e01)
print("====================================")
e02 = repr(e01)
print(e02,type(e02))
print("====================================")
e03 = eval(e02)
e03.ATK = 200
print(e03)
print(e01)
