"""
    测试 List_Helper
"""

from common.list_helper import *

class SkillManager:
    def __init__(self,ID,name,ATK,duration):
        self.ID = ID
        self.name = name
        self.ATK = ATK
        self.duration = duration

    def __str__(self):
        return "{} {}的攻击力是{}，持续时间是{}秒".format(self.ID,self.name,self.ATK,self.duration)

list_skill = [
    SkillManager(101,"乾坤大挪移",100,2),
    SkillManager(102,"降龙十八掌",150,3),
    SkillManager(103,"九阴真经",2000,7)
]


def condition01(item):
    return item.ATK > 200

def condition02(item):
    return 3 <= item.duration <= 7

def condition03(item):
    return item.ID == 102

def condition04(item):
    return len(item.name) >= 4 and item.duration < 6

# 查找多个元素
generator01 = ListHelper.find_all(list_skill,condition02)
for item in generator01:
    print(item)
print("==========================================")

# 查找单个元素
result01 = ListHelper.find_one(list_skill,condition03)
print(result01)


