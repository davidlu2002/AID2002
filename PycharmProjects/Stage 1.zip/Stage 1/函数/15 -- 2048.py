"""
    2048 游戏核心算法
"""

# exercise_01: 定义函数 将0元素移至末尾
def zero_to_end(list_target):
    for i in range(-1,-len(list_target)-1,-1):
        if list_target[i] == 0:
            del list_target[i]
            list_target.append(0)
    return list_target

# exercise_02: 定义函数 相等相邻元素合并
def merge(list_target):
    zero_to_end(list_target)
    for i in range(len(list_target)-1):
         if list_target[i] == list_target[i+1] and list_target[i] != 0:
            list_target[i] += list_target[i]
            del list_target[i+1]
            list_target.append(0)
    return list_target

# exercise_03: 定义函数 移动+合并二维列表元素
# 1 左移
def move_left(list_2D):
    for line in list_2D:
        merge(line)
    return list_2D

# 2 右移
def move_right(list_2D):
    i = 0
    for line in list_2D:
        list_2D[i] = line[::-1]
        merge(list_2D[i])
        list_2D[i] = list_2D[i][::-1]
        i += 1

# 3 上移
def line_to_row(list_target):
    list01 = []
    for r in range(4):
        list02 = []
        for k in range(4):
            list02.append(list_target[k][r])
        list01.append(list02)
    return list01

def move_up(list_2D):
    list_intermediate = line_to_row(list_2D)
    move_left(list_intermediate)
    return line_to_row(list_intermediate)

# 下移
def move_down(list_2D):
    list_intermediate = line_to_row(list_2D)
    move_right(list_intermediate)
    return line_to_row(list_intermediate)



