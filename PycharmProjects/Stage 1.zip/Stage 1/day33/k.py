list01 = [1,2,3,4,5,6]

def generator(list_target):
    for item in list_target:
        if item % 2 == 0:
            yield item

generator01 = generator(list01)
for item in generator01:
    print(item)

# Q1: 为什么生成器只能遍历一次？
# 因为第一次调用后，生成器对象中的next函数中的索引已经达到最大值，第二次调用时会直接raise StopIteration
# for item in generator01:
#     print(item)

# Q2: 为什么列表可以遍历多次？
# 因为iter和next方法不在一个类中，每次调用for循环时，iter函数返回一个新创建的迭代器对象(即新创建一个next函数)
# e.g: 如下列函数所示，两次遍历所调用的迭代器，MyRangeIterator的ID不同
class MyRange:
    def __init__(self,value):
        self.value = value

    def __iter__(self):
        print(id(MyRangeIterator(self.value)))
        return MyRangeIterator(self.value)

class MyRangeIterator:
    def __init__(self,value):
        self.value = value
        self.index = 0

    def __next__(self):
        if self.index == self.value:
            raise StopIteration
        temp = self.index
        self.index += 1
        return temp

for item in MyRange(3):
    print(item)

for item in MyRange(3):
    print(item)