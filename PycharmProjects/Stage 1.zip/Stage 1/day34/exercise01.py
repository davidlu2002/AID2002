"""
    使用内置高阶函数完成以下练习
"""

# exercise01:获取元组中，长度最大的列表
list01 = ([1,1,1],[2,2],[3,3,3,3])
print(max(list01,key = lambda item:len(item)))
print("================================================")

class Enemy:
    def __init__(self,name,HP,ATK,defense):
        self.name = name
        self.HP = HP
        self.ATK = ATK
        self.defense = defense

    def __str__(self):
        return "{}的HP是{}，ATK是{}，DEF是{}".format(self.name,self.HP,self.ATK,self.defense)

list_enemy = [
    Enemy("灭霸",10000,500,1000),
    Enemy("奥创",6000,10000,500),
    Enemy("小丑",500,100000,200),
    Enemy("钢铁侠",0,8000,500)
]

# exercise02:根据敌人列表，获取所有敌人的姓名,ATK,HP
result01 = map(lambda item: (item.name,item.ATK,item.HP), list_enemy)
for item in result01:
    print(item)
print("================================================")

# exercise03: 在敌人列表中，获取攻击力大于5000的所有活的敌人
result02 = filter(lambda item:item.ATK>5000 and item.HP>0, list_enemy)
for item in result02:
    print(item)
print("================================================")

# exercise04:根据防御力对敌人列表进行降序排列
result03 = sorted(list_enemy, key=lambda item:item.defense, reverse=True)
for item in result03:
    print(item)
