class List_Helper:
    def list_h(self):
        print("this is list_helper")

from main import skill_d
skill_d()