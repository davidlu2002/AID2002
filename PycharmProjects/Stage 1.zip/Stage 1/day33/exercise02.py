"""
    # 练习1：
    在list_helper.py中增加通用的求和方法
    案例1：计算敌人列表中所有敌人的总HP
    案例2：总ATK

    # 练习2：
    在list_helper.py中增加通用的筛选方法
    案例1：获取敌人列表中所有敌人的名称
    案例2：获取敌人列表中所有敌人的名称和血量

    # 练习3：
    在list_helper.py中增加通用的获取最大值方法
    案例1：获取敌人列表中攻击力最大的敌人
    案例2：获取敌人列表中防御力最大的敌人

    # 练习4：
    在list_helper.py中增加通用的升序排列方法
    案例1：将敌人列表按照攻击力升序排列
    案例2：将敌人列表按照防御力升序排列
"""

from common.list_helper import *
class Enemy:
    def __init__(self,name,HP,ATK,defense):
        self.name = name
        self.HP = HP
        self.ATK = ATK
        self.defense = defense

    def __str__(self):
        return "{}的HP是{}，ATK是{}，DEF是{}".format(self.name,self.HP,self.ATK,self.defense)

list_enemy = [
    Enemy("灭霸",10000,500,1000),
    Enemy("奥创",6000,10000,500),
    Enemy("小丑",500,100000,200)
]


# exercise01:
# sum_HP = ListHelper.sum_element(list_enemy,lambda item: item.HP)
# print(sum_HP)

# exercise02:
# select01 = ListHelper.select_element(list_enemy,lambda item: item.name)
# for item in select01:
#     print(item)
#
# select02 = ListHelper.select_element(list_enemy, lambda item: (item.name, item.HP))
# for item in select02:
#     print(item)

# exercise03:
# max01 = ListHelper.get_max(list_enemy, lambda item: item.HP)
# print(max01)
#
# max02 = ListHelper.get_max(list_enemy, lambda item: item.ATK)
# print(max02)

# exercise04:
list01 = ListHelper.ascending_sort_list(list_enemy, lambda item: item.ATK)
for enemy in list01:
    print(enemy)

list02 = ListHelper.ascending_sort_list(list_enemy, lambda item: item.defense)
for enemy in list02:
    print(enemy)