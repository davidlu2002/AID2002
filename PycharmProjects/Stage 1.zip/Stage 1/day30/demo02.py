"""
    函数式编程 语法
        将函数作为参数进行传递及执行
"""

# 将函数赋值给变量，就是将函数的功能赋值给变量
a = print
a("今天天气不错")


def fun01():
    print("执行fun01")

def fun02(item):
    print("执行fun02")
    item()

def fun03(item01,item02):
    print("执行fun03")
    item01(item02)

fun03(fun02,fun01)


