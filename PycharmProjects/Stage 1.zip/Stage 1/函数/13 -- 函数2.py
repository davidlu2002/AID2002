"""
    函数返回值 语法
"""
# 参数：调用者传递给定义者的信息
# 返回值：定义者传递给调用者的结果
#        任何一种方法都有返回值，默认值是None
# def fun01(a):
#     print("fun01执行")
#     # 作用：1.返回结果    2.退出方法
#     return 20
# F8 逐过程    （调试时跳过方法）
# F7 逐语句    （调试时进入方法）
# re = fun01()
# print(re)


"""
    函数返回值 应用
"""
# 函数的设计思想：分而治之
#              干一件事
# 需求：两个数字相加的函数
# 错误方法：
# def plus():
#       1. 获取数据
#     number01 = int(input("输入第一个数字："))
#     number02 = int(input("输入第二个数字："))
#       2. 逻辑计算
#     result = number01 + number02
#       3. 显示结果
#     print(result)
# plus()
# 控制台输入两个数字适用性太小(框架、数据来源不同)


# 改进方法(方法定义者只做函数，不管数据来源等)：
def plus(number01,number02):
    # 逻辑处理
    return number01 + number02
# 调用者提供数据
# number01 = int(input("输入第一个数字："))
# number02 = int(input("输入第二个数字："))
# result = plus(number01,number02)
# 调用者负责显示结果
# print(result)


