from skill_system.skill_deployer import skill_d
skill_d()