"""
    自定义函数
"""
# 1 定义
# 用于封装一个特定的功能，是可以重复执行的语句块
#     def：是define的缩写
#     形式参数：方法制作者需要使用者提供的信息
#     语法：
#         1.def 函数名(形式参数):
#             函数体
#         2.最好在函数体第一行写下函数的具体功能/描述
#         3.调用函数直接输入函数名就能打印


# exercise_01:
# def geometry(r_count,c_count,char):
#     """
#         打印矩形
#     :param r_count: 行数
#     :param c_count: 列数
#     :param char: 填充的字符
#     """
#     for r in range(r_count):
#         for c in range(c_count):
#             print(char,end = " ")
#         print()
# r = int(input("请输入行数："))
# c = int(input("请输入列数："))
# geometry(r,c,"*")

# exercise_02: 打印一维列表
# def print_list(list_target):
#     """
#         打印列表
#     :param list_target: 目标列表
#     """
#     for i in list_target:
#         print(i)
# list01 = ["a",1,3,[1,2,3]]
# print_list(list01)

# exercise_03: 打印二维列表
# list02 = [
#     [1,2,3,4,5],
#     [4,5,6],
#     [7,8,9,10,11,12]
# ]
# def print_list02(list_targ):
#     """
#         打印二维列表
#     :param list_targ: 目标列表
#     """
#     for r in list_targ:
#         for i in r:
#             print(i,end = " ")
#         print()
# print_list(list02)



