# exercise01:从列表[4,61,34,21,134,54]中选出所有偶数

# 方法一：结果存入另一个列表
list01 = [4,61,34,21,134,54]
"""
    结果存入新列表中，占内存，但是可以处理所有符合条件的数据
def get_even_number01(list_target):
    result = []
    for number in list01:
        if number % 2 == 0:
            result.append(number)
    return result

list02 = get_even_number01(list01)
print(list02)
"""

"""
    不新建列表，直接打印符合条件的数据，但是只能打印，不能进行其他操作
def get_even_number01(list_target):
    for number in list_target:
        if number % 2 == 0:
            print(number)
get_even_number01(list01)
"""


print("========================================")
# 方法二：使用生成器
"""
    使用生成器，不新建列表存储数据（不占内存），但是可以对所有数据进行操作
def get_even_number02(list_target):
    for item in list_target:
        if item % 2 == 0:
            yield item


for number in get_even_number02(list01):
    print(number)
"""
