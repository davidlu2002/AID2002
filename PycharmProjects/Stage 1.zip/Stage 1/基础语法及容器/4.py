#2020.2.28
#second = int(input("总秒数："))
#hour = second // 3600
#minute = second % 3600 // 60
#second01 = second % 60
#print(str(hour)+"小时"+str(minute)+"分"+str(second01)+"秒")


#a = 1000
#b = 1000
#print(a is b)




#price = float(input("商品单价："))
#number = float(input("商品数量："))
#pay = float(input("付款金额："))
#total_price = price * number
#if total_price > pay:
#    print("金额不足")
#else:
#    exchange = pay - total_price
#    print ("找回金额："+str(exchange))

#调试（debug）
#   目的：审查程序运行时的变量取值
#        审查程序运行的流程
#    步骤：
#         1.加断点
#         2.点Debug(Shift+F9)
#         3.执行一行(F8)
#         4.停止(Ctrl+F2)

# exercise(day04)
#quarter = input("输入一个季节：")
#if quarter == "spring" or quarter == "spring season":
#    print("1-3")
#要注意or的使用: e.g: summer == "spring" or "spring season"为
# False or "spring season"为True(恒成立)

#elif quarter == "summer":
#    print("4-6")
#elif quarter == "fall":
#    print("7-9")
#elif quarter == "winter":
#    print("10-12")
#else:
#    print("季节有错误，请在spring, summer,"
#          "fall, winter中选一个")

#exercise_03
# grade = float(input("输入成绩："))
# if 80 < grade <= 100:
#     print("优秀")
# elif 60 < grade <= 80:
#     print("良好")
# elif grade == 60:
#     print("及格")
# elif 0 <= grade < 60:
#     print("不及格")
# else:
#     print("输入有误")

# number = "偶数" if int(input("number:")) % 2 == 0 else "奇数"
# print(number)


