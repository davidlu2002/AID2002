"""
    元组(与列表唯一的差别是不可变)
"""

# 1 创建元组
# tuple01 = tuple()
# tuple02 = ()


# 2 访问元组
# 可使用索引,切片(语法与列表相同)
# e.g: tuple06 = ("python", "Java", 2020, 2019)
# print(tuple06[1], tuple06[1:3])


# 3 删除元组
# tup07 = (1,2,3)
# del tup07


# 4 列表和元组之间的转换
#     list01 = [1,2,3]
#     tup01 = tuple(list01)

#     tup02 = (1,2,3)
#     list02 = list(tup02)

# exercise_01:
# month = int(input("月份："))
# day = int(input("日："))
# database_month = (31,28,31,30,31,30,31,31,30,31,30,31)
# sum_day = 0
# for i in range(1,month):
#     sum_day += database_month[i]
# sum_day += day
# print(str(month)+"月"+str(day)+"日")
# print("总天数为"+str(sum_day))




