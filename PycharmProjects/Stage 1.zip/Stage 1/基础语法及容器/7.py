# exercise_01
# score = 0
# for i in range(3):
#     import random
#     number_01 = random.randint(1, 10)
#     number_02 = random.randint(1, 10)
#     number_sum = number_01 + number_02
#     answer = int(input(str(number_01)+"+"+str(number_02)+"=？"))
#     if answer == number_sum:
#         score += 10
# print("最终得分为"+str(score)+"分")

# continue: 作用是跳出本次循环
# sum = 0
# for i in range(1,11):
#     if i % 2 == 1:
#         continue
#     sum += i

# 字符串的连接形式
# a = 1
# b = 2
# print("%d+%d=%d" % (a, b, (a+b)))

# a = 1
# b = 2
# print("{}+{}={}" .format(a,b,a+b))

message = "我叫齐天大圣"
print(message[-5:])
