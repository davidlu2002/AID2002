from common.list_helper import *

class Enemy:
    def __init__(self,name,HP,ATK,defense):
        self.name = name
        self.HP = HP
        self.ATK = ATK
        self.defense = defense

    def __str__(self):
        return "{}的HP是{}，ATK是{}，DEF是{}".format(self.name,self.HP,self.ATK,self.defense)

list_enemy = [
    Enemy("灭霸",10000,500,1000),
    Enemy("奥创",6000,10000,500),
    Enemy("小丑",500,100000,200)
]


get01 = ListHelper.find_one(list_enemy, lambda enemy: enemy.name == "灭霸")
print(get01)
print("=========================================")

get02 = ListHelper.find_all(list_enemy, lambda enemey: enemey.ATK > 5000)
for item in get02:
    print(item)

for item in get02:
    print(item)
# list_result = list(get02)
# print(list_result)
# for enemy in list_result:
#     print(enemy)

print("=========================================")

exist01 = ListHelper.is_exist(list_enemy, lambda enemy: enemy.name == "成昆")
print(exist01)
print("=========================================")

exist02 = ListHelper.is_exist(list_enemy, lambda enemy: enemy.defense > 500)
print(exist02)







