"""
    可迭代对象
"""

# 可迭代对象 -- 容器
list01 = [1,2,3,4,5]
# 迭代过程
# for item in list01:
#     print(item)

# 迭代原理
# 面试题：for循环的原理是什么？
#        可以被for的条件是什么？  (有迭代器__iter__的对象)

"""
    以下代码是for循环实现原理
    （即以下代码可以被当做一个方法，其效果与for循环相同）
"""

# 1 获取迭代器
iterator = list01.__iter__()
# 2 循环获取下一个元素
while True:
    try:
        item = iterator.__next__()
        print(item)
# 3 遇到异常停止迭代
    except StopIteration:
        break # 退出循环



