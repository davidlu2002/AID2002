from bil import StudentManagerController
from model import StudentModel

class StudentManagerView:
    """
        学生管理器视图
    """
    def __init__(self):
        self.__manager = StudentManagerController()

    def __display_menu(self):
        print("1)添加学生")
        print("2)显示学生")
        print("3)删除学生")
        print("4)修改学生")
        print("5)按照成绩升序显示学生")

    def __select_menu(self):
        item = input("请输入：")
        if item == "1":
            self.__input_student()
        elif item == "2":
            self.__output_student(self.__manager.stu_list)
        elif item == "3":
            self.__del_student()
        elif item == "4":
            self.__change_student()
        elif item == "5":
            self.__output_student_bygrade()

    def entry(self):
        """
            视图入口
        """
        while True:
            self.__display_menu()
            self.__select_menu()

    def try_test(self,info_name):
        while True:
            info = input("请输入{}：".format(info_name))
            try:
                info = int(info)
            except ValueError:
                print("输入异常，请重新输入")
            else:
                return info

    def __input_student(self):
        """
            输入学生信息
        """
        name = input("请输入姓名：")
        age = self.try_test("年龄")
        grade = self.try_test("成绩")
        stu = StudentModel(name,age,grade)
        self.__manager.add_student(stu)



    def __output_student(self,list_output):
        """
            打印学生信息
        :param list_output: 学生信息列表
        """
        for stu in list_output:
            print("{}号：{}的年龄是{}，成绩是{}".format(stu.ID,stu.name,stu.age,stu.grade))

    def __del_student(self):
        """
            删除学生信息
        """
        ID = self.try_test("需要删除的学生的编号")
        if self.__manager.delete_student(ID):
            print("删除成功")
        else:
            print("删除失败")

    def __change_student(self):
        """
            修改学生信息
        """
        stu = StudentModel()
        stu.ID = self.try_test("需要修改的学生的编号")
        stu.name = input("请输入姓名：")
        stu.age = self.try_test("年龄")
        stu.grade = self.try_test("成绩")
        if self.__manager.update_student(stu):
            print("修改成功")
        else:
            print("修改失败")

    def __output_student_bygrade(self):
        """
            按照成绩升序输出学生信息
        """
        self.__manager.ascending_sort_list()
        self.__output_student(self.__manager.stu_list)