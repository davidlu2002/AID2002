"""
    异常处理
"""
def divide_apple(apple):
    person = int(input("请输入人数："))
    result = apple / person
    print("每人%d个苹果" % (result))
    print("后续逻辑")

# 1 语法：
#       作用：将程序由异常状态转为正常状态
# 建议分门别类的处理

"""
try:

    # 可能出错的代码
    divide_apple(10)
except ValueError:
    print("输入的人数必须是整数")
except ZeroDivisionError:
    print("输入的人数不能是0")
except Exception:
    print("未知错误")
else:
    # 如果异常，不执行else语句
    print("没有出错")
"""

"""
try:
    divide_apple(10)
finally:
    # 无论是否异常，一定会执行的代码
    print("finally")
    # 作用：有不能处理的错误，但是有一定要执行的代码，就放到finally中
            (一般会处理对资源的释放(如连接数据库后执行关闭))
"""


# exercise_01: 定义函数 在控制台中获取成绩(0~100)
#         要求：1 如果异常，继续获取成绩，直到得到正确的成绩

def get_grade():
    while True:
        str_grade = input("请输入成绩：")
        try:
            grade = int(str_grade)
        except:
            print("数值异常")
        else:
            if 0 <= grade <= 100:
                print("输入正确")
                break
            else:
                print("超过范围")
if __name__ == "__main__":
    get_grade()


