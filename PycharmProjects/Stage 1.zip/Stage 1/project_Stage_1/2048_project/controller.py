"""
    2048 游戏核心算法
"""
import random
from model import DirectionModel
from model import Location

class GameCoreController:
    def __init__(self, list_1D = None):
        self.__list_1D = list_1D
        self.__list_2D = [
        [0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0]
    ]
        self.__list_empty_location = []

    @property
    def list_2D(self):
        return self.__list_2D


    def __get_empty_location(self):
        """
            获取二维列表中的空白位置
        """
        # 每次获取空位置前需要清空列表
        self.__list_empty_location.clear()
        for r in range(len(self.list_2D)):
            for k in range(len(self.list_2D)):
                if self.list_2D[r][k] == 0:
                    self.__list_empty_location.append((Location(r,k)))

    def __select_random_number(self):
        """
            产生随机数(2==90%, 4==10%)
        :return: 产生的随机数
        """
        return 4 if random.randint(1,10) == 10 else 2

    def generate_random_number(self):
        """
            在二维列表的随机一个空白位置产生随机数(2 or 4)
        """
        self.__get_empty_location()
        if len(self.__list_empty_location) == 0:
            return

        loc = random.choice(self.__list_empty_location)

        # if random.randint(1,10) == 10:
        #     self.list_2D[loc.r_index][loc.k_index] = 4
        # else:
        #     self.list_2D[loc.r_index][loc.k_index] = 2
        self.list_2D[loc.r_index][loc.k_index] = self.__select_random_number()
        self.__list_empty_location.remove(loc)

    def __zero_to_end(self):
        """
            定义函数 将0元素移至末尾
        :return: 处理后的列表
        """
        for i in range(-1,-len(self.__list_1D)-1,-1):
            if self.__list_1D[i] == 0:
                del self.__list_1D[i]
                self.__list_1D.append(0)

    def __merge(self):
        """
            相等相邻元素合并
            :return: 处理后的列表
        """
        self.__zero_to_end()
        for i in range(len(self.__list_1D)-1):
             if self.__list_1D[i] == self.__list_1D[i+1] and self.__list_1D[i] != 0:
                self.__list_1D[i] += self.__list_1D[i]
                del self.__list_1D[i+1]
                self.__list_1D.append(0)

    def if_game_over(self):
        """
            判断游戏是否结束
        :return: True(游戏结束) False(游戏没有结束)
        """
        # 判断横向竖向是否有相同的元素
        for r in range(len(self.list_2D)):
            for k in range(len(self.list_2D)-1):
                if self.list_2D[r][k] == self.list_2D[r][k+1] or self.list_2D[r][k] == self.list_2D[k+1][r]:
                    return False
                
        # 是否有空位置
        if len(self.__list_empty_location):
            return False

        return True


    def __move_left(self):
        """
            左移
        :return: 处理后的列表
        """
        for line in self.list_2D:
            self.__list_1D = line
            self.__merge()
        self.generate_random_number()

    def __move_right(self):
        """
            右移
        """
        i = 0
        for line in self.list_2D:
            self.__list_1D = line[::-1]
            self.__merge()
            line[::-1] = self.__list_1D
            i += 1
        self.generate_random_number()

    def __square_matrix_transpose(self):
        """
            方阵转置
        """
        for r in range(len(self.list_2D)):
            for k in range(len(self.list_2D)):
                if r > k:
                    self.list_2D[r][k], self.list_2D[k][r] = self.list_2D[k][r], self.list_2D[r][k]

    def __move_up(self):
        """
            上移
        """
        self.__square_matrix_transpose()
        self.__move_left()
        self.__square_matrix_transpose()
        self.generate_random_number()

    def __move_down(self):
        """
            下移
        """
        self.__square_matrix_transpose()
        self.__move_right()
        self.__square_matrix_transpose()
        self.generate_random_number()

    def move(self,direction):
        """
            通用的向指定方向移动合并列表
        :param direction: 指定的方向
        """
        if direction == DirectionModel.UP:
            self.__move_up()
        elif direction == DirectionModel.DOWN:
            self.__move_down()
        elif direction == DirectionModel.LEFT:
            self.__move_left()
        elif direction == DirectionModel.RIGHT:
            self.__move_right()


if __name__ == "__main__":
    list01 = [
        [2,2,0,2],
        [4,2,0,4],
        [4,0,4,0],
        [8,16,8,8]
    ]

    list02 = [
        [0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0]
    ]
    manager = GameCoreController(list02)
    for i in range(10):
        manager.move(DirectionModel.LEFT)
        for line in list02:
            print(line)