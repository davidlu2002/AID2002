# exercise_01:定义函数 计算四位整数，每位相加和
# def plus04(number):
#     """
#         计算四位整数，每位相加和
#     :param number: 四位整数
#     :return: 四位的相加和
#     """
#     return number % 10 + number // 10 % 10 + number // 100 % 10 + number // 1000
# # 调用函数
# number = int(input("输入四位整数："))
# result = plus04(number)
# print(result)

# exercise_02:定义函数 根据两，计算几斤零几两
# def jin_liang_exchange(weight_liang):
#     """
#         根据两，计算几斤零几两
#     :param weight_liang: 两数
#     :return: 元组（斤,两）
#     """
#     jin = weight_liang // 16
#     liang = weight_liang % 16
#     return (jin,liang)
# weight_liang = int(input("输入总两数："))
# result = jin_liang_exchange(weight_liang)
# print(str(result[0])+"斤零"+str(result[1])+"两")

# exercise_03:
# def grade(score):
#     """
#         根据成绩计算等级
#     :param score: 成绩
#     :return: 等级
#     """
#     if score > 100 or score < 0:
#         return "输入有误"
#     if 60 <= score:
#         return "及格"
#     return "不及格"
#
# score = int(input("输入成绩："))
# result = grade(score)
# print(result)

# exercise_04:定义函数 判断列表中是否存在相同项
# list03 = [3,80,45,5,7,1]
#
# def verdict_identical(list_target):
#     """
#         判断列表中是否存在相同项
#     :param list_target: 目标函数
#     :return: 若有相同项，返回True；若没有，返回False
#     """
#     for k in range(0,len(list_target)-1):
#         for i in range(k+1,len(list_target)):
#             if list_target[k] == list_target[i]:
#                 return True
#     return False
# print(verdict_identical(list03))

# exercise_05:定义函数 根据年月，计算有多少天（考虑闰年）
def is_leap_year(year):
    """
        判断是否为闰年
    :param year: 年份
    :return: 闰年的判断方法
    """
    return year % 4 == 0 and year % 100 != 0 or year % 400 == 0

def month_day_exchange(month):
    """
        根据年月，计算有多少天
    :param month: 月份
    :return: 这一年这个月的天数
    """
    if month < 1 or month > 12:
        return 0
    if month == 2:
        return 29 if is_leap_year(year) else 28
    if month in (4,6,9,11):
        return 30
    return 31
# year = int(input("输入年："))
# month = int(input("输入月："))
# print(month_day_exchange(month))

# exercise_06:定义函数 列表升序排列
def list_sort(list_target):
    """
        列表升序排列
    :param list_target: 目标列表
    :return:
    """
    for k in range(len(list_target)-1):
        for i in range(k+1,len(list_target)):
            if list_target[k] > list_target[i]:
                list_target[k],list_target[i] = list_target[i],list_target[k]
list04 = [3,80,45,5,7,1,80]
# list_sort(list04)
# print(list04)

# 满足以下两个条件，就无需通过return传递结果：
#   1.传入的是可变对象
#   2.函数体修改的直接是传入的对象

# exercise_07:定义函数 方阵转置
def list_exchange(list_target):
    """
        方阵转置
    :param list_target: 目标列表
    """
    for r in range(len(list_target)):
        for k in range(len(list_target)):
            if r > k:
                list_target[k][r],list_target[r][k] = list_target[r][k],list_target[k][r]

list05 = [
    [1, 2, 3, 4],
    [5, 6, 7, 8],
    [9, 10, 11, 12],
    [13, 14, 15, 16]
]
# list_exchange(list05)
# for item in list05:
#     print(item)
