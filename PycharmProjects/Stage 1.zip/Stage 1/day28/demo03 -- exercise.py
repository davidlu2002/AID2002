class ATKError(Exception):
    def __init__(self,msg,error_line,ATK,ID):
        self.msg = msg
        self.error_line = error_line
        self.ATK = ATK
        self.ID = ID

class Enemy:
    def __init__(self,ATK):
        self.ATK = ATK

    @property
    def ATK(self):
        return self.__ATK
    @ATK.setter
    def ATK(self,value):
        if 0 <= value <= 100:
            self.__ATK = value
        else:
            raise ATKError("攻击力超出范围",17,value,101)

try:
    enemy01 = Enemy(10)
except ATKError as e:
    print("值异常，{}{}".format(e.ATK,e.msg))
else:
    print("输入正确")
