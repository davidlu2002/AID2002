# exercise_02: 图形管理器记录多个图形
#               迭代图形管理器对象

class Geometry:
    def __init__(self,name):
        self.name = name

class GeometryIterator:
    def __init__(self,target):
        self.__target = target
        self.__index = 0

    def __next__(self):
        if self.__index == len(self.__target):
            raise StopIteration
        self.__index += 1
        return self.__target[self.__index-1]

class __GeometryManager:
    def __init__(self):
        self.__geometry_list = []

    @property
    def geometry_list(self):
        return self.__geometry_list
    @geometry_list.setter
    def geometry_list(self):
        self.__geometry_list = []

    def add_geometry(self,geometry):
        self.__geometry_list.append(geometry)

    def __iter__(self):
        return GeometryIterator(self.__geometry_list)

manager = __GeometryManager()
manager.add_geometry(Geometry("正方形"))
manager.add_geometry(Geometry("长方形"))
manager.add_geometry(Geometry("五边形"))

# for item in manager:
#     print(item.name)

"""
    效果等同于：
"""
# iterator = manager.__iter__()
# while True:
#     try:
#         item = iterator.__next__()
#         print(item.name)
#     except StopIteration:
#         break

"""
    '生成器模式'
def get_geometry(geo_manager):
    for geometry in geo_manager.geometry_list:
        yield geometry

g01 = get_geometry(manager)
for item in g01:
    print(item.name)
"""