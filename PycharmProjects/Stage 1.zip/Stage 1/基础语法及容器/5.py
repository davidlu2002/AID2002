#number_01 = int(input("整数1："))
#number_02 = int(input("整数2："))
#number_03 = int(input("整数3："))
#number_04 = int(input("整数4："))

#max_value = number_01

#if max_value < number_02:
#    max_value = number_02
#if max_value < number_03:
#    max_value = number_03
#if max_value < number_04:
#    max_value = number_04
#print(max_value)

# while True:
#     quarter = input("输入一个季节：")
#     if quarter == "spring" or quarter == "spring season":
#         print("1-3")
#     elif quarter == "summer":
#         print("4-6")
#     elif quarter == "fall":
#         print("7-9")
#     elif quarter == "winter":
#         print("10-12")
#     else:
#         print("季节有错误，请在spring, summer,"
#               "fall, winter中选一个")
#     if input("输入e键退出") == "e":
#         break


count = 1
while count <= 10:
    print(count)
    count += 1

