class MyRange:
    def __init__(self,value):
        self.value = value

    def __iter__(self):
        # return MyRangeIterator(self.value)
        # 0 -- > self.value
        # yield 作用：将下列代码改为迭代器模式的代码
        # 生成规则：
        # 1. 将yield以前的语句定义在next方法内
        # 2. 将yield后面的数据作为next方法返回值
        index = 0
        while index < self.value:
            yield index
            index += 1

"""
class MyRangeIterator:
    def __init__(self,value):
        self.value = value
        self.index = 0

    def __next__(self):
        if self.index == self.value:
            raise StopIteration
        temp = self.index
        self.index += 1
        return temp
"""

for i in MyRange(10):
    print(i)

