# sys.path是一个根目录列表。可以将my_project添加到根目录列表中，与把my_project标蓝效果一致
import sys
sys.path.append("/home/tarena/PycharmProjects/Stage 1/day28/my_project(包调用)")


def skill_m():
    print("this is skill_manager")


from common.double_list_helper import Double_List
if __name__ == "__main__":
    a = Double_List()
    a.double_list_h()
    Double_List.print_name()