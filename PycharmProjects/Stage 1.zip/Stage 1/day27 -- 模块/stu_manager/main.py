from ui import *
v1 = StudentManagerView()
v1.entry()
