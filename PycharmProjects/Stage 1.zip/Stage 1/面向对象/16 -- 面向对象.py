"""
    类和对象
"""
# 类
class wife:
    # 数据成员
    def __init__(self,name,sex):
        # self是调用当前方法的对象地址
        self.name = name
        self.sex = sex

    # 行为成员
    def action(self):
        print(self.name + "玩耍")

# 创建对象,实际在调用__init__方法
# w01 = wife("Lily",22)
# 调用对象的行为（自动将对象地址传入方法）
# w01.action()


# exercise_01:创建两个类，四个对象，并调用其方法
# class clothes:
#     def __init__(self,price,color):
#         self.price = price
#         self.color = color
#     def purchase(self):
#         print("{}色的衣服价格为{}元".format(self.color, self.price))
# clothes01 = clothes(100,"blue")
# clothes02 = clothes(200,"red")
# clothes01.purchase()
# clothes02.purchase()

# class catalyst:
#     def __init__(self,FE,product):
#         self.FE = FE
#         self.product = product
#     def cat_result(self):
#         print("该催化剂以{}%的效率产{}".format(self.FE, self.product))
# catalyst01 = catalyst(99,"C2H4")
# catalyst02 = catalyst(95,"CO")
# catalyst01.cat_result()
# catalyst02.cat_result()

# exercise_02:
# 1 创建学生类
# ---- 数据：姓名,年龄,成绩,性别)
# ---- 行为：在控制台中打印个人信息的行为
# 2 在控制台中循环录入学生信息，如果名称为空，退出录入
# 3 在控制台中输出每个学生信息(调用学生类中的方法)
# 4 打印第一个学生的信息

# dict_student = {}
# while True:
#     name = input("姓名：")
#     if "" == name:
#         break
#     elif name not in dict_student:
#         age = int(input("年龄："))
#         grade = float(input("成绩："))
#         sex = input("性别：")
#         dict_student[name] = [age, grade, sex]
#     else:
#         print("重复输入，请重新输入")
# for name,tuple_student in dict_student.items():
#     print("%s的年龄是%s,成绩为%s,性别是%s" % (name, tuple_student[0], tuple_student[1], tuple_student[2]))

class Student:
    def __init__(self,name,age,grade,sex):
        self.name = name
        self.age = age
        self.grade = grade
        self.sex = sex
    def print_student(self):
        print("%s的年龄是%s,成绩为%s,性别是%s" % (self.name,self.age,self.grade,self.sex))

list_student = []
while True:
    name = input("姓名：")
    if "" == name:
        break
    age = int(input("年龄："))
    grade = float(input("成绩："))
    sex = input("性别：")
    list_student.append(Student(name,age,grade,sex))

for stu in list_student:
    stu.print_student()

list_student[0].print_student()