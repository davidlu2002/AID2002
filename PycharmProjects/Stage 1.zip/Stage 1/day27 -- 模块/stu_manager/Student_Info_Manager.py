"""
    学生管理系统
    项目计划：
            1.完成数据模型类StudentModel
            2.完成逻辑控制类StudentManagerController
"""
# 需求：
# 1 添加学生信息
# 2 显示学生信息
# 3 删除学生信息
# 4 修改学生成绩
# 5 按学生成绩低到高显示学生信息

class StudentModel:
    """
        学生模型
    """
    def __init__(self, name="", age=0, grade=0, ID=0):
        """
            创建学生对象
        :param name: 学生姓名，str类型
        :param age: 年龄，int类型
        :param grade: 成绩，float类型
        :param ID: 学生编号(该学生对象的唯一标识)
        """
        self.ID = ID
        self.name = name
        self.age = age
        self.grade = grade

class StudentManagerController:
    """
        学生管理控制器，负责业务逻辑处理
    """
    def __init__(self):
        self.__stu_list = []

    @property
    def stu_list(self):
        return self.__stu_list

    __initial_ID = 0 # 类变量，初始编号
    def add_student(self,stu_info):
        """
            添加学生
        :param stu_info: 需要添加的学生对象
        """
        StudentManagerController.__initial_ID += 1
        stu_info.ID = StudentManagerController.__initial_ID
        self.stu_list.append(stu_info)

    def delete_student(self,ID):
        """
            根据编号删除学生
        :param ID: 需要删除的学生的编号
        :return: 删除成功/失败
        """
        for student in self.stu_list:
            if student.ID == ID:
                self.stu_list.remove(student)
                return True
        return False

    def update_student(self,stu_upd):
        """
            根据stu_upd.ID修改其他信息
        :param stu_upd: 需要修改的学生信息
        :return: 删除成功/失败
        """
        for student in self.stu_list:
            if student.ID == stu_upd.ID:
                student.name = stu_upd.name
                student.age = stu_upd.age
                student.grade = stu_upd.grade
                return True
        return False

    def ascending_sort_list(self):
        """
            按照成绩升序排列学生
        """
        for k in range(len(self.stu_list) - 1):
            for i in range(k + 1, len(self.stu_list)):
                if self.stu_list[k].grade > self.stu_list[i].grade:
                    self.stu_list[k], self.stu_list[i] = self.stu_list[i],self.stu_list[k]


class StudentManagerView:
    """
        学生管理器视图
    """
    def __init__(self):
        self.__manager = StudentManagerController()

    def __display_menu(self):
        print("1)添加学生")
        print("2)显示学生")
        print("3)删除学生")
        print("4)修改学生")
        print("5)按照成绩升序显示学生")

    def __select_menu(self):
        item = input("请输入：")
        if item == "1":
            self.__input_student()
        elif item == "2":
            self.__output_student(self.__manager.stu_list)
        elif item == "3":
            self.__del_student()
        elif item == "4":
            self.__change_student()
        elif item == "5":
            self.__output_student_bygrade()

    def entry(self):
        """
            视图入口
        """
        while True:
            self.__display_menu()
            self.__select_menu()

    def __input_student(self):
        """
            输入学生信息
        """
        name = input("请输入姓名：")
        age = int(input("请输入年龄："))
        grade = float(input("请输入成绩："))
        stu = StudentModel(name,age,grade)
        self.__manager.add_student(stu)

    def __output_student(self,list_output):
        """
            打印学生信息
        :param list_output: 学生信息列表
        """
        for stu in list_output:
            print("{}号：{}的年龄是{}，成绩是{}".format(stu.ID,stu.name,stu.age,stu.grade))

    def __del_student(self):
        """
            删除学生信息
        """
        ID = int(input("输入需要删除的学生的编号："))
        if self.__manager.delete_student(ID):
            print("删除成功")
        else:
            print("删除失败")

    def __change_student(self):
        """
            修改学生信息
        """
        stu = StudentModel()
        stu.ID = int(input("输入需要修改的学生的编号："))
        stu.name = input("请输入姓名：")
        stu.age = int(input("请输入年龄："))
        stu.grade = float(input("请输入成绩："))
        if self.__manager.update_student(stu):
            print("修改成功")
        else:
            print("修改失败")

    def __output_student_bygrade(self):
        """
            按照成绩升序输出学生信息
        """
        self.__manager.ascending_sort_list()
        self.__output_student(self.__manager.stu_list)

view = StudentManagerView()
view.entry()