"""
    继承 -- 设计
"""

# 需求：老张开车去东北
# 变化：   坐飞机
# class Person:
#     def __init__(self,name):
#         self.name = name
#
#     def go_to(self,vehicle,position):
#         print(self.name+"用",end="")
#         vehicle.transport(position)
#
# class Vehicle:
#     def transport(self,position):
#         pass
#
# class Car(Vehicle):
#     def transport(self,position):
#         print("汽车开到"+position)
#
# class Plane(Vehicle):
#     def transport(self,position):
#         print("飞机飞到"+position)
#
# p01 = Person("a")
# c01 = Car()
# f01 = Plane()
# p01.go_to(c01,"东北")
# p01.go_to(f01,"东北")


# exercise_01:
"""
    手雷炸了，可能伤害敌人/玩家的生命，
             还可能伤害未知事物鸭子，房子...
    要求：增加了新事物，不影响手雷
    体会：继承的作用
         多态的体现
         设计原则
            开闭原则
            单一职责
            依赖倒置
"""
class Bomb:
    def explosion(self,object):
        object.hurt()

class Object:
    def hurt(self):
        pass

class Enemy(Object):
    def hurt(self):
        print("敌人受到了伤害")

class Player(Object):
    def hurt(self):
        print("玩家受到了伤害")

class Duck:
    def hurt(self):
        print("鸭子受到了伤害")

class Bomb2:
    def explosion(self,object):
        print("{}受到了伤害".format(object.name))

class Object2:
    def __init__(self,name):
        self.name = name

duck01 = Object2("鸭子")
player01 = Object2("玩家")
bomb01 = Bomb2()
bomb01.explosion(duck01)
bomb01.explosion(player01)