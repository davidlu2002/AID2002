"""
    字典
"""
# 定义：有一系列键值对组成的可变映射容器
#      键必须唯一且不可变
# 1 创建
# dict01 = {"a":100,"b":80,"c":70}
# dict01 = dict()


# 2 查找(根据key查找value)
# print(dict01["a"])
# 项目中，如果存在键再查找
#    (如果key不存在，会报KeyError)
# e.g:
# if "qtx" in dict01:
#     print(dict01["qtx"])

# 3 修改(之前存在key)
# dict01["a"] = "BB"
# print(dict01["a"])

# 4 添加(之前不存在key)
# dict01["e"] = "F"

# 5 删除
#     del dict01["a"]
#     dict01.pop("a")
#     dict01.clear() 清空dict

# 6 遍历
# 遍历字典，得到的是key
# for i in dict01.keys():
#     print(i)

# 遍历字典，得到的是value
# for i in dict01.values():
#     print(i)

# 都得到：
# 第一种方法：
# for i in dict01.items():
#     print(i)
# 第二种方法：
# for k,v in dict01.items():
#     print(k)
#     print(v)


# exercise_01:
# dict_goods = {}
# while True:
#     goods_name = input("商品名：")
#     if "" == goods_name:
#         break
#     goods_price = float(input("商品单价："))
#     dict_goods[goods_name] = goods_price
# print(dict_goods)
# for key,value in dict_goods.items():
#     print("{}商品单价是{}元".format(key, value))


# exercise_02(字典内嵌列表):
# dict_student = {}
# while True:
#     name = input("姓名：")
#     if "" == name:
#         break
#     elif name not in dict_student:
#         age = int(input("年龄："))
#         grade = float(input("成绩："))
#         sex = input("性别：")
#         dict_student[name] = [age, grade, sex]
#     else:
#         print("重复输入，请重新输入")
# for name,tuple_student in dict_student.items():
#     print("%s的年龄是%s,成绩为%s,性别是%s" % (name, tuple_student[0], tuple_student[1], tuple_student[2]))

# exercise_02(列表内嵌字典):
# list_student = []
# while True:
#     name = input("姓名：")
#     if "" == name:
#         break
#     age = int(input("年龄："))
#     grade = int(input("成绩："))
#     sex = input("性别：")
#     dict_student = {"name":name, "age":age, "grade":grade,"sex":sex}
#     list_student.append(dict_student)
# for dict_student in list_student:
#     print("%s的年龄是%d,成绩是%d,性别是%s" % (dict_student["name"], dict_student["age"], dict_student["grade"], dict_student["sex"]))

"""
    选择策略（列表、字典比较）
    字典：
        优点：读取速度快；代码可读性高于列表
        缺点：内存占用大
             获取值只能根据键，不灵活
    列表：
        优点：根据索引/切片获取元素更灵活
             内存占用小
        缺点：可读性相对于字典更差
"""
