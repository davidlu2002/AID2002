"""
    多继承 -- 语法
"""
class A:
    def m01(self):
        print("A")

class  B(A):
    def m01(self):
        print("B")

class C(A):
    def m01(self):
        print("C")

class D(B,C):
    def m02(self):
        self.m01()

d01 = D()
d01.m02()

# 打印出继承关系的顺序（调用同名方法的顺序）
# [D,B,C,A,object]
print(D.mro())

