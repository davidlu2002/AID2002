# exercise_01:使用迭代器原理，遍历元组

tuple01 = ("铁扇公主","铁锤公主","扳手王子")
iterator = tuple01.__iter__()
while True:
    try:
        item = iterator.__next__()
        print(item)
    except StopIteration:
        break


"""
    '生成器模式'
def tuple_generator(tuple_target):
    for item in tuple_target:
        yield item

t01 = tuple_generator(tuple01)
for item in t01:
    print(item)
"""