"""
    练习一：定义函数，根据年月日，返回星期数
    e.g: 0 "星期一"
         1 “星期二”
"""
# import time
# def get_weekday(year,month,day):
#     time_tuple = time.strptime("{}/{}/{}".format(year,month,day),"%Y/%m/%d")
#     return "星期%s" % (time_tuple.tm_wday + 1)
#
# print(get_weekday(2020,3,31))





