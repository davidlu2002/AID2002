"""
    迭代器
    自定义类，可调用for循环(反向思考）
        （制作迭代器instead of使用）
        （开发者instead of使用者）
"""
# e.g:自定义SKillManager类，可以直接用for循环调用类内的技能列表

class Skill:
    def __init__(self,name):
        self.name = name

class SkillIterator:
    def __init__(self,target):
        self.__target = target
        self.__index = 0

    def __next__(self):
        if self.__index == len(self.__target):
            raise StopIteration
        self.__index += 1
        return self.__target[self.__index-1]

class SKillManager:
    def __init__(self):
        self.__skills = []

    def add_skill(self,skill):
        self.__skills.append(skill)

    def __iter__(self):
        # 创建一个迭代器对象，并传递需要迭代的数据
        return SkillIterator(self.__skills)

manager = SKillManager()
manager.add_skill(Skill("a"))
manager.add_skill(Skill("b"))
manager.add_skill(Skill("c"))


for item in manager:
    print(item)
