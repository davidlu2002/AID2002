class Student:
    def __init__(self,name,age,grade,sex):
        self.name = name
        self.age = age
        self.grade = grade
        self.sex = sex
    def print_student(self):
        print("%s的年龄是%s,成绩为%s,性别是%s" % (self.name,self.age,self.grade,self.sex))

list01 = [
    Student("a",38,100,"male"),
    Student("b",29,62,"male"),
    Student("c",35,96,"female")
]


# exercise_01: 定义函数,在list01中查找name是"c"的同学
# 将名称与年龄打印在控制台中
# def find_c(list_target):
#     for item in list_target:
#         if item.name == "c":
#             print(item.name,item.age)
# find_c(list01)

# exercise_02: 定义函数,在list01查找性别为male的同学
# 将名称与年龄打印在控制台上
# def find_male(list_target):
#     list_male = []
#     for item in list_target:
#         if item.sex == "male":
#             list_male.append(item)
#     return list_male
# list_result = find_male(list01)
# for i in list_result:
#     i.print_student()

# exercise_03: 定义函数 求学生年龄大于30的数量
# def is_over_thirty(stu):
#     if stu.age >= 30:
#         return True
#     return False
#
# def stu_thirty_count(list_target):
#     count = 0
#     for stu in list_target:
#         if is_over_thirty(stu):
#             count += 1
#     return count
# result = stu_thirty_count(list01)
# print(result)

# exercise_04:定义函数 将list01当中所有学生的成绩归零
# def set01():
#     for stu in list01:
#         stu.grade = 0
# set01()

# exercise_05:定义函数 获取list01中所有学生的姓名
# def get_name():
#     result = []
#     for stu in list01:
#         result.append(stu.name)
#     return result
# print(get_name())

# exercise_06:定义函数 在list01中查找年龄最大的学生对象
# def find_max_age():
#     max_stu = list01[0]
#     for i in range(1,len(list01)):
#         if max_stu.age < list01[i].age:
#             max_stu = list01[i]
#     return max_stu
# result = find_max_age()
# result.print_student()


