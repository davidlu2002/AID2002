"""
    列表助手模块
"""
class ListHelper:
    """
        列表助手类
    """
    @staticmethod
    def find_all(list_target,func_condition):
        """
            通用的查找某个条件的多个元素的方法
        :param list_target: 需要查找的列表
        :param func_condition: 需要查找的条件
               函数名(参数) -- > bool
        :return: 需要查找的元素,生成器类型
        """
        for item in list_target:
            if func_condition(item):
                yield item

    @staticmethod
    def find_one(list_target,func_condition):
        """
                    通用的查找某个条件的单个元素的方法
                :param list_target: 需要查找的列表
                :param func_condition: 需要查找的条件
                       函数名(参数) -- > bool
                :return: 需要查找的元素
                """
        for item in list_target:
            if func_condition(item):
                return item

    @staticmethod
    def is_exist(list_target,func_condition):
        """
            通用的判断在一个列表中，是否存在至少一个符合条件的元素的方法
        :param list_target: 目标列表
        :param func_condition: 条件
                函数名(参数) -- > bool
        :return: True(存在)/False(不存在)
        """
        for item in list_target:
            if func_condition(item):
                return True
        return False

    @staticmethod
    def sum_element(list_target,target_element):
        """
            通用的求和方法
        :param list_target: 目标列表
        :param target_element: 需要求和的数据(如HP，ATK等)
        :return: 总和
        """
        sum = 0
        for item in list_target:
            sum += item.target_element
        return sum