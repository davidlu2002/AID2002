"""
    装饰器练习
"""

# 在不改变原有功能的前提下，增加验证账号的功能
def verify(func):
    def wrapper(*args,**kwargs):
        print("账号验证")
        func(*args,**kwargs)
    return wrapper

@verify
def deposit(money):
    print("存了%d钱" % (money))

@verify
def withdraw(money,login_id):
    print("%s取了%d钱" % (login_id,money))

deposit(10000)
withdraw(3000,"abc")
