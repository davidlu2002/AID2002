"""
    装饰器练习2
"""
# 在不改变原有功能的前提下，增加打印函数执行时间的新功能
import time

def print_action_time(func):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        func(*args, **kwargs)
        end_time = time.time()
        print("该函数执行时间为{}秒".format(end_time - start_time))

    return wrapper

@print_action_time
def fun01():
    time.sleep(2)
    print("执行fun01")

@print_action_time
def fun02(a):
    time.sleep(1)
    print("执行fun02,,参数是%s" % (a))

fun01()
fun02(123)
