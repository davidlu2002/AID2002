"""
    使用property(读取方法，写入方法)封装变量
"""
# 1 过渡封装
# class Wife:
#     def __init__(self,name,age,weight):
#         self.name = name
#         # self.age实际上读取了类变量age，而不是重新创建一个实例变量age
#         self.age = age
#         self.weight = weight
#
#     def get_age(self):
#         return self.__age
#     def set_age(self,age):
#         if 18 < age < 31:
#             self.__age = age
#         else:
#             raise ValueError("我不要")
#
#     # 1 创建了一个类变量age
#     # 2 属性 property对象拦截对age类变量的读写操作
#     # 3 property对象使用了两个方法（读取+写入），为实例对象创建了一个实例变量self.__age
#     age = property(get_age,set_age)
#
#     def get_weight(self):
#         return self.__weight
#     def set_weight(self,weight):
#         if 40 <= weight <= 60:
#             self.__weight = weight
#         else:
#             raise ValueError("我不要")
#
#     weight = property(get_weight,set_weight)
# #   weight = property(None,set_weight) 只写
# #   weight = property(get_weight,None) 只读
# w01 = Wife("a",20,50)
# w01.age = 25
# print(w01.age)


"""
    使用属性property封装
"""
class Wife:
    def __init__(self,name,age,weight):
        self.name = name
        # self.age实际上读取了类变量age，而不是重新创建一个实例变量age
        self.age = age
        self.weight = weight
    def show_age(self):
        print(self.age)

    @property # 创建proper对象，只负责拦截读取操作
    def age(self):
        return self.__age
    @age.setter # 只负责拦截写入操作
    def age(self,age):
        if 18 < age < 31:
            self.__age = age
        else:
            raise ValueError("我不要")

    @property
    def weight(self):
        return self.__weight
    @weight.setter
    def weight(self,weight):
        if 40 <= weight <= 60:
            self.__weight = weight
        else:
            raise ValueError("我不要")


# exercise_01:
class Enemy:
    def __init__(self,name,attack,HP):
        self.name = name
        self.attack = attack
        self.HP = HP

    @property
    def attack(self):
        return self.__attack
    @attack.setter
    def attack(self,attack):
        if 10 <= attack <= 50:
            self.__attack = attack
        else:
            raise ValueError("攻击力超出范围")

    @property
    def HP(self):
        return self.__HP
    @HP.setter
    def HP(self,HP):
        if 100 <= HP <= 200:
            self.__HP = HP
        else:
            raise ValueError("血量超出范围")

# exercise_02:用面向对象的思想打出“老张开车去东北”
# class Person:
#     def __init__(self,name):
#         self.name = name
#
#     @property
#     def name(self):
#         return self.__name
#     @name.setter
#     def name(self,name):
#         self.__name = name
#
#     def go_to(self,transportation,destination):
#         print("{}用{}去{}".format(self.name,transportation.type,destination.name))
#
# class Transportation:
#     def __init__(self,type):
#         self.type = type
#
#     @property
#     def transportation(self):
#         return self.__type
#     @transportation.setter
#     def transportation(self,type):
#         self.__type = type
#
# class Destination:
#     def __init__(self,name):
#         self.name = name
#
#     @property
#     def destination(self):
#         return self.__name
#     @destination.setter
#     def destination(self,name):
#         self.__name = name
# lz = Person("老王")
# car = Transportation("飞机")
# destination = Destination("广州")
# lz.go_to(car,destination)


# exercise_03:以面向对象的思想描述：
#             小明在招商银行取钱
class Person:
    def __init__(self,name,money):
        self.name = name
        self.money = money

    @property
    def name(self):
        return self.__name
    @name.setter
    def name(self,name):
        self.__name = name

    @property
    def money(self):
        return self.__money
    @money.setter
    def money(self,money):
        self.__money = money

    def get_money(self,bank,money_amount):
        if money_amount <= bank.total_money:
            self.money += money_amount
            bank.total_money -= money_amount
            print("{}从{}取了{}元".format(self.name,bank.name,money_amount))
        else:
            raise ValueError("存款不足，剩余{}元".format(bank.total_money))


class Bank:
    def __init__(self, name,total_money):
        self.name = name
        self.total_money = total_money

    @property
    def name(self):
        return self.__name
    @name.setter
    def name(self, name):
        self.__name = name

    @property
    def total_money(self):
        return self.__total_money
    @total_money.setter
    def total_money(self,total_money):
        self.__total_money = total_money

xm = Person("小明",0)
zs = Bank("招商银行",1000)
xm.get_money(zs,5000)