# 练习：获取列表中所有字符串/小数
# 要求：分别使用生成器函数/生成器表达式/列表推导式

list01 = [3,"32523",55,"asdf",True,1.6,"Fas"]

# 1 生成器函数
def get_element(list_target,get_type):
    for item in list_target:
        if isinstance(item, get_type):
            yield item

get01 = get_element(list01,str)
get02 = get_element(list01,float)

for item in get01:
    print(item)
for item in get02:
    print(item)
print("============================================")


# 2 生成器表达式
get03 = (item for item in list01 if isinstance(item, str))
for item in get03:
    print(item)
print("============================================")


# 3 列表推导式
get04 = [item for item in list01 if isinstance(item, str)]
print(get04)
