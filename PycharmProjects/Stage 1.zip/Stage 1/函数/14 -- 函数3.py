"""
    作用域
"""
# 全局变量
# g01 = 100

# def fun01():
    # 局部变量：在函数内部定义的变量(函数外不能直接使用)
    # l01 = 100

    # 创建了一个局部变量g01，而不是修改全局变量
    # g01 = "no"

    # 定义全局变量g01，此时修改的是全局变量
    # global g01
    # g01 = "no"
    # print(g01)
#
# fun01()
# print(g01)


# exercise_01:记录一个函数的执行次数
# times = 0
# def fun02():
#     print()
#     global times
#     times += 1
# fun02()
# fun02()
# fun02()
# print("该函数调用%d次" % (times))


"""
    函数参数
        实际参数
"""

def fun01(a,b,c,d):
    print(a)
    print(b)
    print(c)
    print(d)

# 1.位置实参：实参与形参的位置依次对应
# fun01(1,2,3,4)

    # 2.序列实参：位置形参的一种。星号将序列拆分后按位置与形参进行对应
        # 作用：如果参数很多，可以存储在序列（str/list/tuple）中，
        #      再通过*拆分，直接传入函数.
    # list01 = ["a","b","c","d"]
    # fun01(*list01)

# 3.关键字实参：实参与形参根据名称进行对应
# fun01(b=1,d=2,a=3,c=4)

    # 4.字典实参：关键字实参的一种。双星号将字典拆分后按名称与形参进行对应
        # 作用：如果参数很多，可以存储在字典中，
        #      再通过*拆分，直接传入函数.
# dict01 = {"a":1,"c":3,"d":2,"b":4}
# fun01(**dict01)


"""
    函数参数
        形式参数
"""

# 1.缺省(默认)参数：如果实参不提供，可以使用默认值
# def fun01(a = None,b = 0,c = 0,d = 0):
#     print(a)
#     print(b)
#     print(c)
#     print(d)
# 关键字实参 + 缺省形参：调用者可以随意传递参数.
# fun01(b=2, c=3)

# exercise_01:定义函数，根据小时、分钟、秒，计算总秒数
# 要求：可以只计算小时-->秒
#       可以只计算分钟-->秒和其他任意组合
# def time_cal(hour = 0,minute=0,second=0):
#     return hour*3600 + minute*60 + second
# result = time_cal(minute=2)
# print("总秒数为{}秒".format(result))


# 2.位置形参：同位置实参


# 3.星号元组形参：星号将所有实参合并为一个元组
#   作用：让实参个数无限(args:arguments(实参))
# def fun03(*args):
#     print(args)
# fun03(1,"2")

# exercise_02:定义函数，数值相加
# def plus_number(*args):
#     return sum(args)
# print(plus_number(1,2,3,45,32))


# 4.命名关键字形参：在*args以后的位置形参要用关键字传递
# 目的：要求实参必须使用关键字实参.
# def fun04(a,*args,b):
#     print(a)
#     print(args)
#     print(b)
# fun04(1,2,3,b=2)


# 5.双星号字典形参：**将实参合并为字典
        # 作用：实参可以传递数量无限的关键字实参
# def fun05(**kwargs):
#     print(kwargs)
# fun05(a = 1,b=2)


