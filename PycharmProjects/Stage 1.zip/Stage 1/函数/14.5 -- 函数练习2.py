# exercise_01:调用fun07
# def fun07(a,*args,b,**kwargs):
#     print("可")
# fun07(1,2,3,b=2,d=2,e=5,c=1)

# exercise_02:定义函数 计算指定范围内的素数
# def is_prime(number):
#     """
#         判断是否为素数
#     :param number: 数字
#     :return: True:是素数；False:不是素数
#     """
#     for item in range(2, number):
#         if number % item == 0:
#             return False
#     return True
#
# def func_prime(num_start, num_end):
#     """
#         计算指定范围内的素数
#     :param num_start: 开始数字
#     :param num_end: 结束数字
#     :return: 含有所有范围内素数的列表
#     """
#     list_result = []
#     for number in range(num_start,num_end):
#         if is_prime(number):
#             list_result.append(number)
#     return list_result
# print(func_prime(2,30))

# exercise_03: 重构shopping.py


